PROJECT : LIBRARY MANAGEMENT SYSTEM

USED TECHNOLOGIES: MYSQL,PHP,HTML,CSS,JAVASCRIPT

___________________________________________________________________________________________________

How to run the Project

1.Database Configuration
*Open phpmyadmin
*Create Database� named library
*Import database library.sql (available inside zip package)

2. Put library folder(available inside zip package) inside�root(htdocs) directory
(tested in XAMPP server)

3.To run the application,open the web brower and type as below.
	http://localhost/library/index.php

4.To login into the system
 *As A Member Of The Library(Student in the educational center)
	Email:Sumuduliyanage888@gmail.com
	Password:Sumu123
	Type:Member(Student)

 *As A Member Of The Library(Staff in the educational center)
	Email:pushpa@gmail.com
	Password:Pus123
	Type:Member(Staff)

 Note-All The Login Information For Library Members Can Be Found In member Table in the database. Here, I gave only one 
     record.


*As An Administrator
	Email:virajanidharmathilaka@gmail.com
	Password:Admin123
	Type:Library Administration
Note-All The Login Information For Library Administrators Can Be Found In librarian Table in the database.

5.After Successfully logged into the system, You can do different operations.

NOTE-I have included an user guide for you to guide you to use our Library Management System. Our System mainly have three 
     kinds of users. They are library administration, student members , and the staff members(probably teachers,lecturers..)
     in the education center.Please look into our User Guide provided. It clearly says how this system works.
___________________________________________________________________________________________________________________
Please Refer User Guide Provided.
Thank You.










