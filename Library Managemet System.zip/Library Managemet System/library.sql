-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2020 at 05:37 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `Author_id` int(11) NOT NULL,
  `Author_first_name` varchar(255) NOT NULL,
  `Author_last_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`Author_id`, `Author_first_name`, `Author_last_name`) VALUES
(2000, 'William', 'Shakespeare'),
(2001, ' Arthur', 'Miller'),
(2002, 'Martin', 'Wickramasinghe'),
(2003, 'John', 'Cheever'),
(2004, 'Charlotte', 'Bronte'),
(2005, 'Homer', ''),
(2006, 'John', 'Milton'),
(2007, 'K', 'Jayathilake');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `Book_id` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Isbn_no` int(11) NOT NULL,
  `Lending_status` varchar(7) NOT NULL,
  `Availability` tinyint(1) NOT NULL,
  `Price` decimal(10,0) NOT NULL,
  `Type` varchar(255) NOT NULL,
  `Author_id` int(11) DEFAULT NULL,
  `Pub_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`Book_id`, `Title`, `Isbn_no`, `Lending_status`, `Availability`, `Price`, `Type`, `Author_id`, `Pub_id`) VALUES
(100, 'Hamlet', 20035278, 'L', 0, '450', 'Drama', 2000, 10002),
(101, 'The Crucible', 45656421, 'R', 1, '350', 'Drama', 2001, 10000),
(102, 'Madol Doova', 45564212, 'L', 0, '400', 'Novel', 2002, 10003),
(103, 'Gamperaliya', 45566565, 'L', 1, '250', 'Novel', 2002, 10003),
(104, 'Kaliyugaya', 89855665, 'L', 1, '350', 'Novel', 2002, 10003),
(105, 'Hamlet', 20035278, 'L', 1, '450', 'Drama', 2000, 10002),
(106, 'Goodbye', 45655121, 'R', 1, '300', 'Short Stories', 2003, 10002),
(107, 'Jane Eyre', 12123454, 'L', 1, '400', 'Novel', 2004, 10000),
(108, 'Villete', 78954554, 'L', 1, '500', 'Novel', 2004, 10000),
(109, 'The Professor', 78974412, 'L', 1, '240', 'Novel', 2004, 10002),
(110, 'The Odyssey ', 45654212, 'R', 1, '340', 'Poetry', 2005, 10000),
(111, 'Paradise Lost ', 78921212, 'L', 0, '400', 'Poetry', 2006, 10000),
(112, 'A Woman', 12345445, 'L', 0, '230', 'Short Stories', 2002, 10003),
(113, 'Charitha Thunak', 78984212, 'L', 0, '250', 'Novel', 2007, 10001),
(114, 'As You Like It', 89655655, 'R', 1, '320', 'Drama', 2000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `Issue_id` int(11) NOT NULL,
  `Lib_card_no` int(11) DEFAULT NULL,
  `Book_id` int(11) DEFAULT NULL,
  `Issue_date` timestamp NULL DEFAULT current_timestamp(),
  `Duration` int(11) DEFAULT NULL,
  `Returned_date` date DEFAULT NULL,
  `Due_date` date GENERATED ALWAYS AS (`Issue_date` + interval `Duration` day) VIRTUAL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`Issue_id`, `Lib_card_no`, `Book_id`, `Issue_date`, `Duration`, `Returned_date`) VALUES
(200002, 16012, 102, '2020-06-01 18:30:00', 21, NULL),
(200003, 16007, 111, '2020-07-07 18:30:00', 14, NULL),
(200004, 16008, 112, '2020-06-30 18:30:00', 14, NULL),
(200005, 16001, 113, '2020-07-10 15:36:56', 14, NULL),
(200006, 16000, 100, '2020-07-10 15:37:11', 14, NULL);

--
-- Triggers `borrow`
--
DELIMITER $$
CREATE TRIGGER `Is_available` AFTER INSERT ON `borrow` FOR EACH ROW BEGIN

  UPDATE book set Availability = 0 
  where book.Book_id = new.Book_id;
  
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Return_Update` AFTER UPDATE ON `borrow` FOR EACH ROW BEGIN
  IF DATEDIFF(new.Returned_date,old.Due_date)>0 THEN
    UPDATE member SET  fine = DATEDIFF(new.Returned_date,old.Due_date) * 5
    WHERE member.Memeber_id = old.Lib_card_no;
  ELSE
    UPDATE member SET  fine = 0 
    WHERE member.Memeber_id = old.Lib_card_no;
  END IF;
  
  UPDATE book SET Availability = 1
  where book.Book_id = old.Book_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `Librarian_id` int(11) NOT NULL,
  `Email_address` varchar(255) NOT NULL,
  `Password` text NOT NULL,
  `Name` varchar(65) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`Librarian_id`, `Email_address`, `Password`, `Name`) VALUES
(100200, 'virajanidharmathilaka@gmail.com', 'Admin123', 'Virajani Dharmathilaka');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `Memeber_id` int(11) NOT NULL,
  `Fine` decimal(10,0) DEFAULT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Librarian_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`Memeber_id`, `Fine`, `Email`, `Password`, `Librarian_id`) VALUES
(16000, '0', 'Sumuduliyanage888@gmail.com', 'Sumu123', 100200),
(16001, '0', 'Miraclescience888@gmail.com', 'Wasa123', 100200),
(16002, '0', 'comandtechworld@gmail.com', 'Dams123', 100200),
(16003, '0', 'Ruwan1997perera@gmail.com', 'Ruwa123', 100200),
(16004, '0', 'kisarur@gmail.com', 'Thar123', 100200),
(16005, '0', 'smviraj@gmail.com', 'Dula123', 100200),
(16006, '0', 'Wsna524@gmail.com', 'Tharush123', 100200),
(16007, '0', 'Tharushini234@gmail.com', 'Nesa123', 100200),
(16008, '0', 'pasindumal@gmail.com', 'Pasi123', 100200),
(16009, '0', 'Thehanpremaratne@gmail.com', 'Theha123', 100200),
(16010, '0', 'Sirilper45@gmail.com', 'Siri123', 100200),
(16011, '0', 'Nalindasilva56@gmail.com', 'Nalin123', 100200),
(16012, '0', 'Lalith234@gmail.com', 'Lali123', 100200),
(16013, '0', 'pushpa@gmail.com', 'Pus123', 100200),
(16014, '0', 'Pali234pere@gmail.com', 'Pali123', 100200);

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `Pub_id` int(11) NOT NULL,
  `Pub_name` varchar(255) NOT NULL,
  `Contact_no` int(10) NOT NULL,
  `Address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`Pub_id`, `Pub_name`, `Contact_no`, `Address`) VALUES
(10000, 'McMillan', 112285162, 'No 220, Lotus Road,Pettah'),
(10001, 'Sarasawi', 112356457, 'No345,Slave roal,Colombo 3'),
(10002, 'Bloomsbury', 414562812, 'No 342,Kalidasa Rd, Matara'),
(10003, 'Wasana', 912523552, 'No 456,Koggala, Galle');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff-id` int(11) NOT NULL,
  `No_address` int(11) NOT NULL,
  `Street_address` text NOT NULL,
  `City_address` text NOT NULL,
  `First_name` varchar(255) NOT NULL,
  `Last_name` varchar(255) NOT NULL,
  `Contact_no` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff-id`, `No_address`, `Street_address`, `City_address`, `First_name`, `Last_name`, `Contact_no`) VALUES
(16010, 33, 'Panideniya', 'Kandy', 'Siril', 'Perera', 778599964),
(16011, 36, 'Alfred Rd', 'Colombo', 'Nalinda', 'Silva', 716656556),
(16012, 77, 'Magalle', 'Galle', 'Lalith', 'Wickramasinghe', 785565565),
(16013, 90, 'Walgana', 'Matara', 'Pushpa', 'Gunethilaka', 778665654),
(16014, 424, 'Galaha', 'Kandy', 'Palitha', 'Fernando', 773556565);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Student_id` int(11) NOT NULL,
  `No_address` int(11) NOT NULL,
  `Street_address` text NOT NULL,
  `City_address` text NOT NULL,
  `First_name` varchar(255) NOT NULL,
  `Last_name` varchar(255) NOT NULL,
  `Contact_no` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Student_id`, `No_address`, `Street_address`, `City_address`, `First_name`, `Last_name`, `Contact_no`) VALUES
(16000, 123, 'Kalidasa Rd', 'Matara', 'Sumudu', 'Liyanage', 778588861),
(16001, 345, 'Lotus Rd', 'Pettah', 'Wasana', 'Parackrama', 712545565),
(16002, 126, 'Slave Rd', 'Colombo 3', 'Damsi', 'Silva', 781221121),
(16003, 567, 'Henry Rd', 'Galle', 'Ruwan', 'Perera', 775664421),
(16004, 88, 'Perakumba rd', 'Kurunegala', 'Tharindu', 'Herath', 715545554),
(16005, 4, 'Galaha', 'Kandy', 'Dulaj', 'Sithika', 716565654),
(16006, 332, 'Kalla', 'Hambantota', 'Tharushini', 'Ekanayake', 764545454),
(16007, 45, 'Rahula Rd', 'Matara', 'Nesandi', 'Mindara', 781212111),
(16008, 64, 'Alfred Gardens', 'Colombo 3', 'Pasindu ', 'Malshan', 775565622),
(16009, 778, 'Queens Rd', 'Colombo 3', 'Thehan', 'Premarathne', 774545555);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`Author_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`Book_id`),
  ADD KEY `Author_id` (`Author_id`),
  ADD KEY `Pub_id` (`Pub_id`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`Issue_id`),
  ADD KEY `Book_id` (`Book_id`),
  ADD KEY `Lib_card_no` (`Lib_card_no`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`Librarian_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`Memeber_id`),
  ADD KEY `Librarian_id` (`Librarian_id`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`Pub_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff-id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `Author_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2008;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `Book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `Issue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200007;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `Librarian_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100201;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `Memeber_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30009;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `Pub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10004;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`Author_id`) REFERENCES `author` (`Author_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`Pub_id`) REFERENCES `publisher` (`Pub_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `borrow`
--
ALTER TABLE `borrow`
  ADD CONSTRAINT `borrow_ibfk_1` FOREIGN KEY (`Book_id`) REFERENCES `book` (`Book_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `borrow_ibfk_2` FOREIGN KEY (`Lib_card_no`) REFERENCES `member` (`Memeber_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `member`
--
ALTER TABLE `member`
  ADD CONSTRAINT `member_ibfk_1` FOREIGN KEY (`Librarian_id`) REFERENCES `librarian` (`Librarian_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`Staff-id`) REFERENCES `member` (`Memeber_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Student_id`) REFERENCES `member` (`Memeber_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
