<!DOCTYPE html>
<html>
    <head>

    	 <style>
			body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	font-size: 35px;
			  	text-align: center;
			  }

			  
              input[type=submit] {
                  font-size: 25px;
                  color: rgb(13, 13, 112);  
                  height: 50px;
                  width: 500px;
                  background: rgb(114, 114, 130);
                  align-self: center;
                  border-radius: 12px;    
            }

			  
		</style>

		<h1>Library Administration</h1>
        
    </head>
    <body>
    	<label for="admin">Admin</label><br>
    	<label for="emaillabeladmin">You are logged as :</label>

        <?php
        	include 'db_connection.php';
        	$conn = OpenCon();
        	$email = $_GET['email'];
            $adminid;
        	echo $email;


            $sql_query1 = "select * from librarian where Email_address ='".$email."' ";
            $res1 = $conn->query($sql_query1);
            if (mysqli_num_rows($res1) > 0) {                    
                while ($ro1 = mysqli_fetch_array($res1)) { 
                    $adminid  = $ro1["Librarian_id"];
                }                     
                unset($res1); 
            } 



        	echo "<br>";
			echo "<br>";

        	echo "<form action=\"bookissue.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button1\"  maxlength=\"4\" size=\"50\" value=\"Issue Book\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"bookreturn.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button2\"  maxlength=\"4\" size=\"50\" value=\"Return Book\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"payfine.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button3\"  maxlength=\"4\" size=\"50\" value=\"Pay Fine\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"register.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
        	echo "<input type=\"submit\" id=\"button4\"  maxlength=\"4\" size=\"50\" value=\"Registration\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";


			echo "<form action=\"searchitem.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button9\"  maxlength=\"4\" size=\"50\" value=\"Search An Item\">";
        	echo "</form>";

        	echo "<br>";


        	echo "<form action=\"deleteitem.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button10\"  maxlength=\"4\" size=\"50\" value=\"Delete An Item\">";
        	echo "</form>";

        	echo "<br>";

			echo "<form action=\"adminsettings.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
            echo "<input type=\"hidden\" name=\"adminid\" value=\"$adminid\"/> ";
        	echo "<input type=\"submit\" id=\"button8\"  maxlength=\"4\" size=\"50\" value=\"Other Settings\">";
        	echo "</form>";


            echo "<br>";

            echo "<form action=\"viewall.php\" method=\"post\">";
            echo "<input type=\"submit\" id=\"button11\"  maxlength=\"4\" size=\"50\" value=\"View All\">";
            echo "</form>";

            echo "<br>";

            echo "<form action=\"index.php\" method=\"post\">";
            echo "<input type=\"submit\" id=\"button4\"  maxlength=\"4\" size=\"50\" value=\"Log Out\">";
            echo "</form>";
            
		   	


        ?>
    </body>
</html>