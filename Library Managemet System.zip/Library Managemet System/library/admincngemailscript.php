<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$newemail = mysqli_real_escape_string($conn,$_POST["newemail"]);
	$oldemail = mysqli_real_escape_string($conn,$_POST["oldemail"]);
	$adminid = mysqli_real_escape_string($conn,$_POST["adminid"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$trueemail;

	$sql = "select * from librarian where Librarian_id ='".$adminid."' ";
    $result = $conn->query($sql);
    if (mysqli_num_rows($result) > 0) {                    
        while ($row = mysqli_fetch_array($result)) { 
            $trueemail  = $row["Email_address"];
        }                     
        unset($result); 
    } 




	if ($oldemail == $trueemail){
		$sql1 = "select count(*) as cntEmail from librarian where Email_address ='".$newemail."'";
		$result1 = mysqli_query($conn,$sql1);
		$row1 = mysqli_fetch_array($result1);
		$countemail = $row1['cntEmail'];
		if ($countemail > 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!New Email Is Already Used By Another Admin! ";
			echo "</dialog>"; 
		}
		else{
			

			$sql_query1 = "UPDATE `librarian` SET `Email_address` = '".$newemail."' WHERE `librarian`.`Email_address` = '".$oldemail."'";

			if(mysqli_query($conn, $sql_query1)){
				echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
				echo "<dialog open>";
				echo "Email Was Changed Successfully";
				echo "</dialog>";
				
			
			} else{
				echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
			}

		}

	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Error!!<br>Current Email Is Wrong";
		echo "</dialog>"; 
	}


?>