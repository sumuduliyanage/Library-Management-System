<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$name = mysqli_real_escape_string($conn,$_POST["name"]);
	$password = mysqli_real_escape_string($conn,$_POST["password"]);
	$email = mysqli_real_escape_string($conn,$_POST["email"]);
	$adminid;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql1 = "select count(*) as cntEmail from librarian where Email_address ='".$email."'";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$countemail = $row1['cntEmail'];
	if ($countemail > 0){
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Error!!<br>This Email Is Already Used By Another Admin! ";
		echo "</dialog>"; 
	}
	else{
		
		$sql_query1 = " INSERT INTO `librarian` (`Librarian_id`, `Email_address`, `Password`, `Name`) VALUES (NULL, '".$email."', '".$password."', '".$name."')";


		if(mysqli_query($conn, $sql_query1)){

			$sql4 = "SELECT * FROM librarian WHERE Email_address = '".$email."' ";

			$result4 = $conn->query($sql4); 
			if (mysqli_num_rows($result4) > 0) { 	       
				while ($row4 = mysqli_fetch_array($result4)) { 
					$adminid = $row4["Librarian_id"];
				}			        
					unset($result4); 				
			} 


			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "New Admin Was Added Successfully!<br><br>";
			echo "Admin Id:".$adminid."<br><br>";
			echo "Email Address:".$email."<br><br>";
			echo "Name:".$name."<br><br>";
			echo "Thank You!";
			echo "</dialog>";
				
			
		} else{
				echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}
	

?>