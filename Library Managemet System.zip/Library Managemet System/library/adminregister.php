<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;    
			    

			  }
			  input[type=submit] {
				  font-size: 16px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}
    	</style>
        <h1>Add A New Admin</h1>
    </head>
    <body>

    	<?php 
    		include 'db_connection.php';
			$conn = OpenCon();
			
			
   			echo "<br>";
		

        echo "<form action=\"adminnewaddcript.php\" method=\"post\">";
    	echo "<fieldset>";

    		echo "<table width =\"500px\" class=\"center\">";

    		echo "<tr><td>";
    		echo "<label for=\"fnamelbl\">Email :</label>";
    		echo "</td><td>";
			echo "<input type=\"text\" id=\"email\"  name=\"email\" required><br><br>";
			echo "</td></tr>";

			echo "<tr><td>";
			echo "<label for=\"lnamelbl\">Name :</label>";
			echo "</td><td>";
			echo "<input type=\"text\" id=\"name\"  name=\"name\" required><br><br>";
			echo "</td></tr>";

			echo "<tr><td>";
			echo "<label for=\"lnamelbl\">Password :</label>";
			echo "</td><td>";
			echo "<input type=\"text\" id=\"password\"  name=\"password\" required><br><br>";
			echo "</td></tr>";
	  		  
	  		echo "<tr><td>";
	  		echo "</td><td>";
			echo "<input type=\"submit\" id=\"add\"  maxlength=\"4\" size=\"50\" value=\"Add\">";
			echo "</td></tr>";

			echo "</table>";

	    	echo "</fieldset>";
			  
			echo "</form>";

	?>

    </body>
</html>