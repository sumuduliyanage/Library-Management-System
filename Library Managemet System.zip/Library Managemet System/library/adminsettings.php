<!DOCTYPE html>
<html>
    <head>
    	<style>
			body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  input[type=submit] {
				  font-size: 25px;
				  color: rgb(13, 13, 112);  
				  height: 50px;
				  width: 500px;
				  background: rgb(114, 114, 130);
				  align-self: center;
				  border-radius: 12px;	  
			}

			  
		</style>

        <h1>Admin Settings</h1>
    </head>
    <body>

        <?php 
    		include 'db_connection.php';
			$conn = OpenCon();
			$email = mysqli_real_escape_string($conn,$_POST["adminemail"]);
			$adminid = mysqli_real_escape_string($conn,$_POST["adminid"]);

			echo "<img src=\"photos/picsettings.jpg\" alt=\"Settings\" width=\"100\" height=\"100\" class=\"center\"><br><br>";
			echo "Admin<br>";
   			echo "You are logged as: ";
   			echo $email;
   			echo "<br><br>";
		


			echo "<br>";
			//echo "<br>";

			echo "<form action=\"adminpswdchange.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"adminid\" value=\"$adminid\"/> ";
        	echo "<input type=\"submit\" id=\"button1\"  maxlength=\"4\" size=\"50\" value=\"Change Password\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"adminemailchange.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"adminid\" value=\"$adminid\"/> ";
        	echo "<input type=\"submit\" id=\"button2\"  maxlength=\"4\" size=\"50\" value=\"Change Email Address\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"adminregister.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button3\"  maxlength=\"4\" size=\"50\" value=\"Register A New Admin\">";
        	echo "</form>";

	       
	?>

    </body>
</html>