<!DOCTYPE html>
<html>
    <head>
    	<style>
			body {background-color:rgb(204, 204, 255);

			 
		    }
			h1 {
			  color: rgb(0,0,0);
			  text-align: center;
			  font-family: verdana;
			  font-size: 300%;
			}	
			label{
				color: black;
				font-size: 150%;
			}
			fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }

			input[type=submit] {
				  font-size: 21px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}

			img {
			  display: block;
			  margin-left: auto;
			  margin-right: auto;
			}

			.wrapper1{
				text-align: center;
				font-size: 25px;
				height: 38px;
			}
			.wrapper2{
				text-align: center;
				font-size: 10px;
				height: 18px;
			}
			  

		</style>

        <h1> LIBRARY MANAGEMENT SYSTEM </h1>
	
    </head>

    <body>

    	 <script>
		    var i = 0 ;
		    var images = [];
		    var time = 3000;

		    images[0] = 'photos/pic1.jpg';
		    images[1] = 'photos/pic2.jpeg';
		    images[2] = 'photos/pic3.jpg';
		    images[3] = 'photos/pic4.png';
		    images[4] = 'photos/pic5.jpg';

		    function changeimg(){
		      document.slide.src = images[i];

		      if (i < images.length - 1){
		        i++;
		      }
		      else{
		        i=0;
		      }

		      setTimeout("changeimg()",time);
		    }

		    window.onload = changeimg;

  		</script>

  		<img name = "slide" width="498" height="470" class="center" style="width: 100%" border="2">

  		<br><br><br>
  		<p style="font-size:30px;color:rgb(10, 16, 87);" align="center"><i> <b>Reading Makes A Full Man.........</b></i></p><br>

  		<p style="font-size:30px" align="center"> <b>Login To Your Account</b></p>


    	

		<form action="login.php" method="post" >
    		<fieldset style="background-color:#9999ff">
			<table width ="400px" >
	
			<tr>
			<td  >
			  <label for="emaillabel">Email </label>
			</td>
			<td>
			  <input type="text" id="email"   size="30" name="email" required>
			</td>

			</tr>
			<tr>
			<td >
			  <label for="passwordlabel">Password </label>
			</td>
			<td>
			  <input type="password" id="password" name="password" required>
			</td>
			</tr>
			<tr>
			<td >	
			  <label for="typelabel">Type </label>
			</td>
			<td>	
			  <select id="type_user" name="type_user" autofocus>
				  <option value="userst">Member(Student)</option>
				   <option value="usersf">Member(Staff)</option>
				  <option value="staff">Library Administration</option>	  
			 </select>
			 </td>
			 </tr>
			</table>
			<br>
			 <div class="wrapper1">
			 	<input type="submit" id="login"  maxlength="4" size="50" value="Login">
			 </div>
			  

    		</fieldset>
		  
		</form>

		<form action="forgetpasswd.php" method="post">
			<div class="wrapper2">
				<input type="submit" id="button1"  maxlength="4" size="20" value="Forgot Password?" align="center" style="font-size : 14px;height: 23px;"/>
			</div>
		</form>


		<br><br>

		
		

		
        
    </body>
</html>