<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	color: rgb(77,25,0);
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }
			  input[type=submit] {
				  font-size: 16px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}
    	</style>
        <h1>Register An Author</h1>
    </head>
    <body>
        <form action="authorregisterscript.php" method="post">
    		<fieldset>

    		  <label for="fnamelbl">First Name :</label>
			  <input type="text" id="fname"  name="fname" required><br><br>

			  <label for="lnamelbl">Last Name :</label>
			  <input type="text" id="lname" name="lname" required><br><br>
  
			  <input type="submit" id="required"  maxlength="4" size="50" value="Register">

    		</fieldset>
		  
		</form>
    </body>
</html>