<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$fname = mysqli_real_escape_string($conn,$_POST["fname"]);
	$lname = mysqli_real_escape_string($conn,$_POST["lname"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";
	

	$sql1 = "INSERT INTO `author` (`Author_id`, `Author_first_name`, `Author_last_name`) VALUES (NULL, '".$fname."', '".$lname."')";

	

	if(mysqli_query($conn, $sql1)){

		$sql2 = "SELECT * FROM author WHERE Author_id = (SELECT max(Author_id) FROM author)";

		$result2 = $conn->query($sql2); 
		if (mysqli_num_rows($result2) > 0) { 
						       
			while ($row2 = mysqli_fetch_array($result2)) { 
				$authorid = $row2["Author_id"];
			} 
						        
				unset($result2); 
						
		} 



		echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Author Was Registered Successfully.<br><br>";
		echo "<br>Details: <br><br>";
		echo "Author Id: ".$authorid."<br><br>";
		echo "First Name: ".$fname."<br><br>";
		echo "Last Name: ".$lname."<br><br>";
		echo "<br>Thank You!";
		echo "</dialog>"; 
	} else{
		echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
	}
	

?>