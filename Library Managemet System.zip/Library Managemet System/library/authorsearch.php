<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$authorid = mysqli_real_escape_string($conn,$_POST["authorid"]);
	$fname = mysqli_real_escape_string($conn,$_POST["fname"]);
	$lname = mysqli_real_escape_string($conn,$_POST["lname"]);
	echo "<body style='background-color:rgb(204, 204, 255)'>";
	$book;
	$i = 0;
	$j = 1;

	if ($authorid != ""){

		

		$sql = "select count(*) as cntAuthor from author where Author_id ='".$authorid."'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_array($result);
		$count = $row['cntAuthor'];
		if ($count <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Author Id <br> The Author Id You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{


			$sql1 = "select * from author where Author_id ='".$authorid."' ";
			$result1 = $conn->query($sql1); 
			if (mysqli_num_rows($result1) > 0) { 			       
				while ($row1 = mysqli_fetch_array($result1)) { 
					$fname = $row1["Author_first_name"];
					$lname = $row1["Author_last_name"];
				} 				        
				unset($result1); 				
			}
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Results 1 <br><br> ";
			echo "__________________________________________________________________________<br><br>";
			echo "Author Id: ".$authorid."<br><br>";
			echo "Name: ".$fname." ".$lname."<br><br>";
			echo "Books: ";

			$sql3 = "select * from book where Author_id ='".$authorid."'  ";
			$result3 = $conn->query($sql3); 
			if (mysqli_num_rows($result3) > 0) { 
				$i = 0;			       
				while ($row3 = mysqli_fetch_array($result3)) { 
					if ($i != 0){
						echo " ,";
					}
					$book = $row3["Title"];
					echo $book;
					$i = 1;
				} 				        
				
				unset($result3);
			} 
			
			if ($i==0){
				echo "No Books";
			} 
			echo "</dialog>";

		}

	}
	elseif ($fname != "") {


		//checks whether that name is in author table
		$sql2 = "select count(*) as cntAuthorname from author where Author_first_name ='".$fname."' and Author_last_name = '".$lname."' ";
		$result2 = mysqli_query($conn,$sql2);
		$row2 = mysqli_fetch_array($result2);
		$countauthor2 = $row2['cntAuthorname'];

		if ($countauthor2 <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!! Author Name You Gave Does Not Exist.<br>Please Give The Correct  Author's First Name And Last Name ";
			echo "</dialog>"; 
		}
		else{



			$sql3 = "select * from author where Author_first_name ='".$fname."' and Author_last_name = '".$lname."' ";

			$result3 = $conn->query($sql3); 

			if (mysqli_num_rows($result3) > 0) { 			       
				while ($row3 = mysqli_fetch_array($result3)) { 
					$authorid = $row3["Author_id"];//we can have many ids
					echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "Results ".$j." <br><br><br> ";
					echo "__________________________________________________________________________<br><br>";
					echo "Author Id: ".$authorid."<br><br>";
					echo "Name: ".$fname." ".$lname."<br><br>";
					echo "Books: ";

					
					$j = $j + 1;

					

					//books wrote by the author
					$sql4 = "select * from book where Author_id ='".$authorid."'  ";
					$result4 = $conn->query($sql4); 
					$i=0;
					if (mysqli_num_rows($result4) > 0) { 
						$i = 0;			       
						while ($row4 = mysqli_fetch_array($result4)) { 
							if ($i != 0){
								echo " ,";
							}
							$book = $row4["Title"];
							echo $book;
							$i = 1;
						} 				        
						
						unset($result4);
					} 
					
					if ($i==0){
						echo "No Books";
					} 
					echo "</dialog>";
					echo "<br><br><br><br><br><br><br><br><br><br><br><br>";

				} 				        
				unset($result3); 

			} 



		}
		
	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Empty Search!!!!!!!!!!! ";
		echo "</dialog>"; 
	}

?>