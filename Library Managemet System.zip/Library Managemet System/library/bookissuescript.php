<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$member_id = mysqli_real_escape_string($conn,$_POST["member_id"]);
	$book_id = mysqli_real_escape_string($conn,$_POST["book_id"]);
	$duration = mysqli_real_escape_string($conn,$_POST["duration"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";


	$sql_query2 = "select count(*) as noUser from member where Memeber_id ='".$member_id."'";
	$result4 = mysqli_query($conn,$sql_query2);
	$row4 = mysqli_fetch_array($result4);
	$countnouser = $row4['noUser'];

	//checking whether the user id is valid
	if ($countnouser<1){
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "ERROR <br>Wrong Member ID <br>There Is No Member With That ID";
		echo "</dialog>";
	}

	else{
		$sql_query3 = "select count(*) as noBook from Book where Book_id ='".$book_id."'";
		$result5 = mysqli_query($conn,$sql_query3);
		$row5 = mysqli_fetch_array($result5);
		$countnobook = $row5['noBook'];

		//checking whether the book id is valid
		if ($countnobook <1){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "ERROR <br>Wrong Book ID <br>There Is No Book With That ID";
			echo "</dialog>";
		}
		else{

			//checking whether this reader has already taken a book
			$sql_query1 = "select count(*) as cntUser from borrow where Lib_card_no ='".$member_id."' and  Returned_date is null";

			$result1 = mysqli_query($conn,$sql_query1);
			$row1 = mysqli_fetch_array($result1);

			$count = $row1['cntUser'];
			$keepingbookid;
			$keepingbookname;
			$kissuedate;
			$kduedate;
				
			if($count > 0){   
				echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>"; 
				echo "<dialog open>";
				echo "<b>This Person Is Keeping Another Book And He Hasn't Returned It Yet. So, We Can't Issue This Book <br><br><br>Details<b><br><br>";
				echo "Member ID: ";
				echo $member_id;
				echo "<br><br>";
				echo "Book ID of the book he is keeping: ";


				$sql1 = "select * from borrow where Lib_card_no ='".$member_id."' and Returned_date is null";
				$result2 = $conn->query($sql1); 
			    if (mysqli_num_rows($result2) > 0) { 
					       
			    	while ($row2 = mysqli_fetch_array($result2)) { 
					    $keepingbookid = $row2["Book_id"];
					    $kissuedate = $row2["Issue_date"];
					    $kduedate = $row2["Due_date"];
					} 
					        
					unset($result2); 
					echo $keepingbookid;
				} 
				
				echo "<br><br>";

				echo "Title Of The Book: ";
				$sql2 = "select * from book where book_id ='".$keepingbookid."'";
				$result3 = $conn->query($sql2); 
				if (mysqli_num_rows($result3) > 0) { 
					       
					while ($row3 = mysqli_fetch_array($result3)) { 
					    $keepingbookname = $row3["Title"];
					} 
					        
					unset($result3); 
					echo $keepingbookname;
				} 
				echo "<br><br>";
				echo "Issued Date: ";
				echo $kissuedate;
				echo "<br><br>";
				echo "Due Date: ";
				echo $kduedate;
				echo "<br><br>";

				echo "</dialog>";
				        
		}else{
				$lending_stat;
				$availability;
				$sql3 = "select * from book where Book_id ='".$book_id."' ";
				$result6 = $conn->query($sql3); 
			    if (mysqli_num_rows($result6) > 0) { 
					       
			    	while ($row6 = mysqli_fetch_array($result6)) { 
					    $lending_stat = $row6["Lending_status"];
					    $availability  = $row6["Availability"];
					} 
					        
					unset($result6); 
				} 

				if ($lending_stat == 'R'){
					echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "ERROR <br>Sorry, This Book Is A Reference Book.<br> This Book Is Not For Lending<br>Thank You!";
					echo "</dialog>";
				}  

				elseif ($availability == 0) {
					echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
				    echo "<dialog open>";
					echo "ERROR <br>Sorry, This Book Is Not Currently Available At The Library.<br>Thank You!";
					echo "</dialog>";  	
				}    

				else{
					$sql4 = "INSERT INTO `borrow` (`Issue_id`, `Lib_card_no`, `Book_id`, `Issue_date`, `Duration`, `Returned_date`) VALUES (NULL, '".$member_id."', '".$book_id."' , current_timestamp(), '".$duration."', NULL);";

					if(mysqli_query($conn, $sql4)){
						echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
						echo "<dialog open>";
					    echo "Book Was Issued Successfully.<br>Thank You!";
					    echo "</dialog>"; 
					} else{
					    echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
					}
				}  
				
		}



	  }
	}

	

?>