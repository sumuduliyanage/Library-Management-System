<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }
			  input[type=submit] {
				  font-size: 16px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}
    	</style>
        <h1>Register A Book</h1>
    </head>
    <body>
        <form action="bookregscript.php" method="post">
    		<fieldset>
    		 <table width ="500px" class="center">

    		  <tr>
    		  	<td>
    		  <label for="titlelbl">Title :</label>
    		  	</td>
    		  	<td>
			  <input type="text" id="title"  name="title" required><br><br>
			    </td>
			</tr>

			<tr>
    		  	<td>
			  <label for="isbnlbl">ISBN No :</label>
			  </td>
    		  	<td>
			  <input type="text" id="isbnno" name="isbnno" required><br><br>
			   </td>
			</tr>

			   <tr>
    		  	<td>
			  <label for="lendingststlbl">Lending Status :</label>
			   </td>
    		  	<td>
			  <select id="lendstat" name="lendstat" autofocus>
				  <option value="L">L</option>
				  <option value="R">R</option>  
			  </select><br><br>
			  </td>
			</tr>


			<tr>
    		  	<td>
			  <label for="pricelbl">Price(Rs) :</label>
			  </td>
    		  	<td>
			  <input type="text" id="price"  name="price" required><br><br>
			   </td>
			</tr>

			<tr>
    		  	<td>
			  <label for="typelbl">Book Type :</label>
			  </td>
    		  	<td>
			  <select id="type" name="type" autofocus>
				  <option value="Novel">Novel</option>
				  <option value="Short Stories">Short Stories</option>  
				  <option value="Drama">Drama</option>
				  <option value="Poetry">Poetry</option>  
				  <option value="Educational">Educational</option>
				  <option value="Magazine">magazine</option>  
			  </select><br><br>
			  </td>
			</tr>

			  
			  <tr>
    		  	<td>
			  <label for="authoridlbl">Author Id :</label>
			  </td>
    		  	<td>
			  <input type="text" id="authorid"  name="authorid" ><br><br>
			   </td>
			</tr>

			<tr>
    		  	<td>
			  <label for="msglbl">If You Forget Author Id , Please Fill First Name And Last Name Of Author</label><br>
			    </td>
			</tr>

			<tr>
    		  	<td>	
			  <label for="authorfnamelbl">Author's First Name :</label>
			   </td>
    		  	<td>
			  <input type="text" id="authorfname"  name="authorfname" ><br>
			   </td>
			</tr>

			  <tr>
    		  	<td>	
			  <label for="authorlnamelbl">Author's Last Name :</label>
			  </td>
    		  	<td>
			  <input type="text" id="authorlname"  name="authorlname" ><br><br>
			  </td>
			</tr>


			   <tr>
    		  	<td>
			  <label for="pubidlbl">Publisher Id :</label>
			  </td>
    		  	<td>
			  <input type="text" id="pubid"  name="pubid" ><br><br>
			   </td>
			</tr>

				 <tr>
    		  	<td>
			  <label for="msglbl">If You Forget Publisher Id , Please Fill Name Of The Publisher</label><br>
			   </td>
			</tr>

			   <tr>
    		  	<td>
			  <label for="pubnamelbl">Publisher Name :</label>
			  </td>
    		  	<td>
			  <input type="text" id="pubname"  name="pubname" ><br><br>
			   </td>
			</tr>


			 <tr>
    		  	<td>
			</td>
    		  	<td>
			  <input type="submit" id="required"  maxlength="4" size="50" value="Register" class="center">
			   </td>
			</tr>

		</table>

    		</fieldset>
		  
		</form>
    </body>
</html>