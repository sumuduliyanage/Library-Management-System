<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$title = mysqli_real_escape_string($conn,$_POST["title"]);
	$isbnno = mysqli_real_escape_string($conn,$_POST["isbnno"]);
	$lendstat = mysqli_real_escape_string($conn,$_POST["lendstat"]);
	$price = mysqli_real_escape_string($conn,$_POST["price"]);
	$type = mysqli_real_escape_string($conn,$_POST["type"]);
	$authorid = mysqli_real_escape_string($conn,$_POST["authorid"]);
	$authorfname = mysqli_real_escape_string($conn,$_POST["authorfname"]);
	$authorlname = mysqli_real_escape_string($conn,$_POST["authorlname"]);
	$pubid = mysqli_real_escape_string($conn,$_POST["pubid"]);
	$pubname = mysqli_real_escape_string($conn,$_POST["pubname"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$isauthoridcorrect = 0;
	$ispubidcorrect = 0;
	$bookid;

	//checks whether author id is not empty
	if ($authorid != ""){

		//checks whether that id is in the author table
		$sql1 = "select count(*) as cntAuthor from author where Author_id ='".$authorid."'";
		$result1 = mysqli_query($conn,$sql1);
		$row1 = mysqli_fetch_array($result1);
		$countauthor = $row1['cntAuthor'];
		if ($countauthor <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!! Author Id You Gave Does Not Exist.<br>Please Give The Correct Author Id <br> Or Author's First Name And Last Name ";
			echo "</dialog>"; 
		}
		else{
			$isauthoridcorrect = 1;
		}
							
	}
	elseif ($authorfname != "" ) {

		//checks whether that name is in author table
		$sql2 = "select count(*) as cntAuthorname from author where Author_first_name ='".$authorfname."' and Author_last_name = '".$authorlname."' ";
		$result2 = mysqli_query($conn,$sql2);
		$row2 = mysqli_fetch_array($result2);
		$countauthor2 = $row2['cntAuthorname'];

		if ($countauthor2 <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!! Author Name You Gave Does Not Exist.<br>Please Give The Correct Author Id <br> Or Author's First Name And Last Name ";
			echo "</dialog>"; 
		}
		else if ($countauthor2 == 1){

			$sql3 = "select * from author where Author_first_name ='".$authorfname."' and Author_last_name = '".$authorlname."' ";
			$result3 = $conn->query($sql3); 
			if (mysqli_num_rows($result3) > 0) { 			       
				while ($row3 = mysqli_fetch_array($result3)) { 
					$authorid = $row3["Author_id"];
				} 				        
				unset($result3); 
				$isauthoridcorrect = 1;			
			} 
		}
		else{
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!! Sorry We Have Found ".$countauthor2." Authors With The Same Name.<br>Their Author Ids And Written Books Are Below.<br>";
			echo "Select The Correct Author Id From Them.";

			$sql4 = "select * from author where Author_first_name ='".$authorfname."' and Author_last_name = '".$authorlname."' ";
			$result4 = $conn->query($sql4); 
			if (mysqli_num_rows($result4) > 0) { 			       
				while ($row4 = mysqli_fetch_array($result4)) { 
					$cur_authorid = $row4["Author_id"];
					echo "<br><br>Author Id: ".$cur_authorid."<br>";
					echo "His Books: ";


					$sql5 = "select * from book where Author_id ='".$cur_authorid."' ";
					$result5 = $conn->query($sql5); 
					if (mysqli_num_rows($result5) > 0) { 
						$i = 1;			       
						while ($row5 = mysqli_fetch_array($result5)) { 
							if ($i != 1 ){
								echo " ,";
							}
							echo  $row5["Title"];
							$i = 0;
						} 				        
						unset($result5);
						echo "<br<br>"; 			
					} 
					else{
						echo "No Books<br>";
					}


				} 				        
				unset($result4); 
						
			} 
			echo "</dialog>"; 
		}
		
	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Error!! You have't given any details about the author.<br>Please fill necessary details.";
		echo "</dialog>"; 
	}


	//if author details are correct, then we think about the publisher details
	if ($isauthoridcorrect == 1 ){

		//checks whether author id is not empty
		if ($pubid != ""){

			//checks whether that id is in the author table
			$sq1 = "select count(*) as cntPub from publisher where Pub_id ='".$pubid."'";
			$res1 = mysqli_query($conn,$sq1);
			$ro1 = mysqli_fetch_array($res1);
			$countpub = $ro1['cntPub'];
			if ($countpub <= 0){
				echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
				echo "<dialog open>";
				echo "Error!! publisher Id You Gave Does Not Exist.<br>Please Give The Correct publisher Id <br> Or Publisher Name. ";
				echo "</dialog>"; 
			}
			else{
				$ispubidcorrect = 1;
			}
								
		}
		elseif ($pubname != "" ) {

			//checks whether that name is in author table
			$sq2 = "select count(*) as cntPubname from publisher where Pub_name ='".$pubname."'  ";
			$res2 = mysqli_query($conn,$sq2);
			$ro2 = mysqli_fetch_array($res2);
			$countpub2 = $ro2['cntPubname'];

			if ($countpub2 <= 0){
				echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
				echo "<dialog open>";
				echo "Error!! Publisher Name You Gave Does Not Exist.<br>Please Give The Correct Publisher Id <br> Or Publisher Name ";
				echo "</dialog>"; 
			}
			else if ($countpub2 == 1){

				$sq3 = "select * from publisher where Pub_name ='".$pubname."' ";
				$res3 = $conn->query($sq3); 
				if (mysqli_num_rows($res3) > 0) { 			       
					while ($ro3 = mysqli_fetch_array($res3)) { 
						$pubid = $ro3["Pub_id"];
					} 				        
					unset($res3); 
					$ispubidcorrect = 1;			
				} 
			}
			else{
				echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
				echo "<dialog open>";
				echo "Error!! Sorry We Have Found ".$countpub2." Publishers With The Same Name.<br>Their Publisher Ids And  Books Are Below.<br>";
				echo "Select The Correct Publisher Id From Them.";

				$sq4 = "select * from publisher where Pub_name ='".$pubname."' ";
				$res4 = $conn->query($sq4); 
				if (mysqli_num_rows($res4) > 0) { 			       
					while ($ro4 = mysqli_fetch_array($res4)) { 
						$cur_pubid = $ro4["Pub_id"];
						echo "<br><br>Publisher Id: ".$cur_pubid."<br>";
						echo "Their Books: ";


						$sq5 = "select * from publisher where Pub_id ='".$cur_pubid."' ";
						$res5 = $conn->query($sq5); 
						if (mysqli_num_rows($res5) > 0) { 
							$i = 1;			       
							while ($ro5 = mysqli_fetch_array($res5)) { 
								if ($i != 1 ){
									echo " ,";
								}
								echo  $ro5["Title"];
								$i = 0;
							} 				        
							unset($res5);
							echo "<br<br>"; 			
						} 
						else{
							echo "No Books<br>";
						}


					} 				        
					unset($res4); 
							
				} 
				echo "</dialog>"; 
			}
			
		}
		else{
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!! You have't given any details about the Publisher.<br>Please fill necessary details.";
			echo "</dialog>"; 
		}

	}

	if (($isauthoridcorrect == 1)  && ($ispubidcorrect == 1)){

		$sql_query1 = "INSERT INTO `book` (`Book_id`, `Title`, `Isbn_no`, `Lending_status`, `Availability`, `Price`, `Type`, `Author_id`, `Pub_id`) VALUES (NULL, '".$title."', '".$isbnno."', '".$lendstat."', '1', '".$price."', '".$type."', '".$authorid."', '".$pubid."')";

		if(mysqli_query($conn, $sql_query1)){

			$sql8 = "SELECT * FROM book WHERE Book_id = (SELECT max(Book_id) FROM book)";

			$result8 = $conn->query($sql8); 
			if (mysqli_num_rows($result8) > 0) { 
							       
				while ($row8 = mysqli_fetch_array($result8)) { 
					$bookid = $row8["Book_id"];
				} 
							        
					unset($result8); 
							
			} 
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Book Was Registered Successfully.";
			echo "<br><br><br>Details: <br><br>";
			echo "Book Id: ".$bookid."<br><br>";
			echo "Title: ".$title."<br><br>";
			echo "Author Id: ".$authorid."<br><br>";
			echo "Type: ".$type."<br><br>";
			echo "Lending Status: ".$lendstat."<br><br>";
			echo "Price: ".$price."<br><br>";
			echo "publisher Id: ".$pubid."<br><br>";

			echo "<br>Thank You!";
				echo "</dialog>"; 
		} else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}
	


?>