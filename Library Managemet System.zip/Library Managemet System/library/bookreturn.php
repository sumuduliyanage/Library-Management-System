<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }
			  input[type=submit] {
				  font-size: 16px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}
    	</style>
        <h1>Return A Book</h1>
    </head>
    <body>
        <form action="bookreturnscript.php" method="post">
    		<fieldset>

    		
    		<table width ="500px" class="center">

    		 <tr><td>
    		  <label for="member_idlbl">Member ID :</label>
    		  </td><td>
			  <input type="text" id="member_id"  name="member_id" required><br><br>
			  </td></tr>

			  <tr><td>
			  <label for="book_idlbl">Book ID   :    </label>
			  </td><td>
			  <input type="text" id="book_id"  name="book_id" required><br><br>
			  </td></tr>

			  <tr><td>
			  </td><td>
			  <input type="submit" id="return"  maxlength="4" size="50" value="Return">
			  </td></tr>

			 </table>

    		</fieldset>
		  
		</form>
    </body>
</html>