<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$member_id = mysqli_real_escape_string($conn,$_POST["member_id"]);
	$book_id = mysqli_real_escape_string($conn,$_POST["book_id"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$bookidborrowtb;
	$booknameborrowtb;
	$fine;


	$sql_query1 = "select count(*) as noUser from member where Memeber_id ='".$member_id."'";
	$res1 = mysqli_query($conn,$sql_query1);
	$ro1 = mysqli_fetch_array($res1);
	$countnouser = $ro1['noUser'];

	//checking whether the user id is valid
	if ($countnouser<1){
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "ERROR <br>Wrong Member ID <br>There Is No Member With That ID";
		echo "</dialog>";
	}

	else{
		$sql_query2 = "select count(*) as noBook from Book where Book_id ='".$book_id."'";
		$res2= mysqli_query($conn,$sql_query2);
		$ro2 = mysqli_fetch_array($res2);
		$countnobook = $ro2['noBook'];

		//checking whether the book id is valid
		if ($countnobook <1){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "ERROR <br>Wrong Book ID <br>There Is No Book With That ID";
			echo "</dialog>";
		}

		else{
			//check whether this member has already returned the book
			$sql1 = "select * from borrow where Lib_card_no ='".$member_id."' and Returned_date is null";
			$result1 = $conn->query($sql1); 
			if (mysqli_num_rows($result1) > 0) { 
						       
				while ($row1 = mysqli_fetch_array($result1)) { 
					$bookidborrowtb = $row1["Book_id"];
				} 
							        
				unset($result1); 

				//checking whether he is giving another book
				$sql2 = "select * from book where Book_id ='".$bookidborrowtb."' ";
				$result2 = $conn->query($sql2);
				if (mysqli_num_rows($result2) > 0) { 
							       
					    	while ($row2 = mysqli_fetch_array($result2)) { 
							    $booknameborrowtb = $row2["Title"];
							} 
							        
							unset($result2); 
				}  

				if ($book_id != $bookidborrowtb){
					echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "ERROR <br>Sorry, Wrong Book Id!<br>The Book Id Of the Book You Should Return Is :";
					echo $bookidborrowtb; 
					echo "<br>The Name Of the Book You Should Return Is :";
					echo $booknameborrowtb;
					echo "<br>Thank You!";
					echo "</dialog>";
				}
				else{
				
					$sql3 = "UPDATE `borrow` SET `Returned_date` = current_timestamp() WHERE `borrow`.`Lib_card_no` = '".$member_id."' and Returned_date is null";

					if(mysqli_query($conn, $sql3)){


						$sql4 = "select * from member where Memeber_id ='".$member_id."' ";
						$result4 = $conn->query($sql4);
						if (mysqli_num_rows($result4) > 0) { 
							       
					    	while ($row4 = mysqli_fetch_array($result4)) { 
							    $fine = $row4["Fine"];
							} 
							        
							unset($result4); 
						}  


						echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
						echo "<dialog open>";
						echo "Book Was Returned Successfully.<br>";
						echo "Thank You!<br><br>";
						echo "Details<br><br><br>";

						echo "Book Id: ";
						echo $book_id;
						echo "<br><br>Book Title: ";
						echo $booknameborrowtb;
						echo "<br><br>Fine: ";
						echo $fine;
						echo "<br><br>";

						if ($fine > 0){
							echo "The Above Fine Should Be Paid !!!!!";
						}

						echo "</dialog>"; 
					} else{
						echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($link);
					}
			    }
		}

		else{
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "ERROR <br>This Member Is Not Keeping Any Book<br> He Has Returned All The Books He Has Taken";
			echo "</dialog>";
		} 


	  }
	}

	
	

?>