<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$bookid = mysqli_real_escape_string($conn,$_POST["bookid"]);
	$title = mysqli_real_escape_string($conn,$_POST["title"]);

	$authorid;
	$pubid;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	if ($bookid != ""){

		$sql1 = "select count(*) as cntBook from book where Book_id ='".$bookid."'";
		$result1 = mysqli_query($conn,$sql1);
		$row1 = mysqli_fetch_array($result1);
		$countbook = $row1['cntBook'];
		if ($countbook <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Book Id <br> The Book Id You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{
			$sql2 = "SELECT * FROM book WHERE Book_id = '".$bookid."' ";

			$result2 = $conn->query($sql2); 
			if (mysqli_num_rows($result2) > 0) { 
				
				$i = 1;		       
				while ($row2 = mysqli_fetch_array($result2)) { 
					echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "Search Results ".$i."<br>";
					echo "__________________________________________________________________________<br><br>";
					echo "Book Id: ".$row2["Book_id"]."<br><br>";
					echo "Title: ".$row2["Title"]."<br><br>";
					echo "ISBN No: ".$row2["Isbn_no"]."<br><br>";
					echo "Type: ".$row2["Type"]."<br><br>";
					echo "Availability: ".$row2["Availability"]."<br><br>";
					echo "Lending Status: ".$row2["Lending_status"]."<br><br>";
					echo "Price: ".$row2["Price"]."<br><br>";
					echo "Author Id: ".$row2["Author_id"]."<br><br>";
					echo "Publisher Id: ".$row2["Pub_id"]."<br><br>";

					$authorid = $row2["Author_id"];
					$pubid = $row2["Pub_id"];

					//showing author name
					$sql5 = "select * from author where Author_id ='".$authorid."'";
					$result5 = $conn->query($sql5); 
			    	if (mysqli_num_rows($result5) > 0) { 
			       
				        while ($row5 = mysqli_fetch_array($result5)) { 
				          echo "Author Name: ".$row5["Author_first_name"]." ".$row5["Author_last_name"]."<br><br>"; 
				        }     
			        	unset($result5); 
			    	} 

			    	//showing publisher name
			    	$sql6 = "select * from publisher where Pub_id ='".$pubid."'";
					$result6 = $conn->query($sql6); 
			    	if (mysqli_num_rows($result6) > 0) { 
			       
				        while ($row6 = mysqli_fetch_array($result6)) { 
				          echo "Publisher Name: ".$row6["Pub_name"]."<br><br>"; 
				        }     
			        	unset($result6); 
			    	} 




					echo "</dialog>"; 
					echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";

				} 
					$i = $i+1;		        
					unset($result2); 
							
			} 
		}
	}
	elseif ($title != "") {
		$sql3 = "select count(*) as cntBook2 from book where Title ='".$title."'";
		$result3 = mysqli_query($conn,$sql3);
		$row3 = mysqli_fetch_array($result3);
		$countbook2 = $row3['cntBook2'];
		if ($countbook2 <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Book Name <br> The Book Name You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{
			$sql4 = "SELECT * FROM book WHERE Title = '".$title."' ";

			$result4 = $conn->query($sql4); 
			if (mysqli_num_rows($result4) > 0) { 
					$i = 1;		       
				while ($row4 = mysqli_fetch_array($result4)) { 
					echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "Search Results ".$i."<br>";
					echo "__________________________________________________________________________<br><br>";
					echo "Book Id: ".$row4["Book_id"]."<br><br>";
					echo "Title: ".$row4["Title"]."<br><br>";
					echo "ISBN No: ".$row4["Isbn_no"]."<br><br>";
					echo "Type: ".$row4["Type"]."<br><br>";
					echo "Availability: ".$row4["Availability"]."<br><br>";
					echo "Lending Status: ".$row4["Lending_status"]."<br><br>";
					echo "Price: ".$row4["Price"]."<br><br>";
					echo "Author Id: ".$row4["Author_id"]."<br><br>";
					echo "Publisher Id: ".$row4["Pub_id"]."<br><br>";

					$authorid = $row4["Author_id"];
					$pubid = $row4["Pub_id"];

					//showing author name
					$sql5 = "select * from author where Author_id ='".$authorid."'";
					$result5 = $conn->query($sql5); 
			    	if (mysqli_num_rows($result5) > 0) { 
			       
				        while ($row5 = mysqli_fetch_array($result5)) { 
				          echo "Author Name: ".$row5["Author_first_name"]." ".$row5["Author_last_name"]."<br><br>"; 
				        }     
			        	unset($result5); 
			    	} 

			    	//showing publisher name
			    	$sql6 = "select * from publisher where Pub_id ='".$pubid."'";
					$result6 = $conn->query($sql6); 
			    	if (mysqli_num_rows($result6) > 0) { 
			       
				        while ($row6 = mysqli_fetch_array($result6)) { 
				          echo "Publisher Name: ".$row6["Pub_name"]."<br><br>"; 
				        }     
			        	unset($result6); 
			    	} 



					echo "</dialog>"; 
					$i = $i + 1;
					echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";

				} 
							        
					unset($result4); 
							
			} 

		}
		
	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open><b>";
		echo "<p style = \"color:red\"> Oops!!</p>";
		echo "Empty Search! ";
		echo "<b></dialog>"; 
	}




?>