<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$authorid = mysqli_real_escape_string($conn,$_POST["authorid"]);
	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql1 = "select count(*) as cntUser from author where Author_id ='".$authorid."'";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$count = $row1['cntUser'];
	if ($count <= 0){
		echo "<dialog open>";
		echo "Error!!Couldn't Delete.<br>Wrong Author Id <br> ";
		echo "</dialog>"; 
	}
	else{
		$sql = "delete from author where Author_id = '".$authorid."'";

		if(mysqli_query($conn, $sql)){
			echo "<dialog open>";
			echo "Deleted!!!!!!!!";
			echo "</dialog>"; 
				
		} 
		else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}

?>