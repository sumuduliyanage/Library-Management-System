<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$bookid = mysqli_real_escape_string($conn,$_POST["bookid"]);
	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql1 = "select count(*) as cntBook from book where Book_id ='".$bookid."'";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$countbook = $row1['cntBook'];
	if ($countbook <= 0){
		echo "<dialog open>";
		echo "Error!!Couldn't Delete.<br>Wrong Book Id <br> ";
		echo "</dialog>"; 
	}
	else{
		$sql = "delete from book where Book_id = '".$bookid."'";

		if(mysqli_query($conn, $sql)){
			echo "<dialog open>";
			echo "Deleted!!!!!!!!";
			echo "</dialog>"; 
				
		} 
		else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}

?>