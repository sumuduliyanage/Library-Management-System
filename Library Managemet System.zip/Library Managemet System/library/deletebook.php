<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }


    	</style>
        <h1>Delete A Book</h1>
    </head>
    <body>

        <form action="deletebkscript.php" method="post">
    		<fieldset>

    		  <label for="bookidlbl"> Book Id: </label>
    		  <input type="text" id="bookid"  name="bookid" ><br><br>

    		 
			  <input type="submit" id="delete1"  maxlength="4" size="50" value="Delete"><br><br>

    		</fieldset>  
		</form>

    </body>
</html>