<!DOCTYPE html>
<html>
    <head>

         <style>
            body {background-color:rgb(204, 204, 255);}

            
              h1{
                
                font-size: 35px;
                text-align: center;
              }

              input[type=submit] {
          font-size: 25px;
          color: rgb(13, 13, 112);  
          height: 50px;
          width: 500px;
          background: rgb(114, 114, 130);
          align-self: center;
          border-radius: 12px;    
      }

              
        </style>

        <h1>Delete An Item</h1>
        
    </head>
    <body>
       

        <?php
            

            echo "<br>";
            echo "<br>";

            echo "<form action=\"deletebook.php\" method=\"post\">";
            echo "<input type=\"submit\" id=\"button1\"  maxlength=\"4\" size=\"50\" value=\"Delete A Book\">";
            echo "</form>";

            echo "<br>";
            //echo "<br>";

            echo "<form action=\"deletemem.php\" method=\"post\">";
            echo "<input type=\"submit\" id=\"button2\"  maxlength=\"4\" size=\"50\" value=\"Delete A Member\">";
            echo "</form>";

            echo "<br>";
            //echo "<br>";

            echo "<form action=\"deleteauthor.php\" method=\"post\">";
            echo "<input type=\"submit\" id=\"button3\"  maxlength=\"4\" size=\"50\" value=\"Delete An Author\">";
            echo "</form>";

            echo "<br>";
            //echo "<br>";

            echo "<form action=\"deletepub.php\" method=\"post\">";
            echo "<input type=\"submit\" id=\"button4\"  maxlength=\"4\" size=\"50\" value=\"Delete A Publisher\">";
            echo "</form>";

            echo "<br>";
            //echo "<br>";

                   
            
        ?>
    </body>
</html>