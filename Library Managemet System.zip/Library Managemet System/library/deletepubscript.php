<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$pubid = mysqli_real_escape_string($conn,$_POST["pubid"]);
	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql1 = "select count(*) as cntUser from publisher where Pub_id ='".$pubid."'";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$count = $row1['cntUser'];

	if ($count <= 0){
		echo "<dialog open>";
		echo "Error!!Couldn't Delete.<br>Wrong Publisher Id <br> ";
		echo "</dialog>"; 
	}
	else{
		$sql = "delete from publisher where Pub_id = '".$pubid."'";

		if(mysqli_query($conn, $sql)){
			echo "<dialog open>";
			echo "Deleted!!!!!!!!";
			echo "</dialog>"; 
				
		} 
		else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}

?>