<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$memid = mysqli_real_escape_string($conn,$_POST["memid"]);
	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql1 = "select count(*) as cntUser from member where Memeber_id ='".$memid."'";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$count = $row1['cntUser'];
	if ($count <= 0){
		echo "<dialog open>";
		echo "Error!!Couldn't Delete.<br>Wrong Member Id <br> ";
		echo "</dialog>"; 
	}
	else{
		$sql = "delete from member where Memeber_id = '".$memid."'";

		if(mysqli_query($conn, $sql)){
			echo "<dialog open>";
			echo "Deleted!!!!!!!!";
			echo "</dialog>"; 
				
		} 
		else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}

?>