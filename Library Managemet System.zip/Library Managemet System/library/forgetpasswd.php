<!DOCTYPE html>
<html>
    <head>
    	<style>
			body {background-color:rgb(204, 204, 255);

			 
		    }
			h1 {
			  color: rgb(0,0,0);
			  text-align: center;
			  font-family: verdana;
			  font-size: 300%;
			}	
			label{
				color: black;
				font-size: 150%;
			}
			fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }

			input[type=submit] {
				  font-size: 21px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}

			  

		</style>

        <h1> Forget The Password? </h1>
	
    </head>

    <body>

    	 


    	<form >
    		<fieldset style="background-color:#9999ff">

    		  <label for="emaillabel">Please Contact The Administration. <br>Contact No: 0412283192<br>Email: libraryedu@gmail.com</label>
			  	  
    		</fieldset>
		</form>

		


		<br><br>

		
		

		
        
    </body>
</html>