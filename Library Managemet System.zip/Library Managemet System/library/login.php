<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$user_email = mysqli_real_escape_string($conn,$_POST["email"]);
	$user_password = mysqli_real_escape_string($conn,$_POST["password"]);
	$user_type = mysqli_real_escape_string($conn,$_POST["type_user"]);
	$user_id;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	

	if ($user_type == "userst"){

		if ($user_email!= "" && $user_password != ""){

			$sql_query = "select count(*) as cntUser from member where Email='".$user_email."' and binary Password='".$user_password."'";

			$result = mysqli_query($conn,$sql_query);
			$row = mysqli_fetch_array($result);

			$count = $row['cntUser'];
		
			if($count > 0){  

				//getting the member id of that email
				$sql1 = "select * from member where Email ='".$user_email."'";
				$result1 = $conn->query($sql1); 
			    if (mysqli_num_rows($result1) > 0) { 
			       
			        while ($row1 = mysqli_fetch_array($result1)) { 
			           $user_id = $row1["Memeber_id"];
			        } 
			        
			        unset($result1); 
			    } 

			    //checking whether that id is in the Student table
			    $sql_query2 = "select count(*) as cntStudent from student where student.Student_id ='".$user_id."' ";
				$result2 = mysqli_query($conn,$sql_query2);
				$row2 = mysqli_fetch_array($result2);
				$count2 = $row2['cntStudent'];
				if ($count2 > 0 ){
					header("Location: userst_account.php?email=".$user_email);
				}
				else{
					echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\" ><br>";
					echo "<dialog open>Invalid Email or Password or User Type</dialog>";
					
				}
               
			 }else{
			        echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			 		echo "<dialog open>Invalid Email or Password or User Type</dialog>";
			 }

	   }

    }
		else if ($user_type == "staff"){
		
			if ($user_email!= "" && $user_password != ""){

			    $sql_query = "select count(*) as cntUser from Librarian where Email_address='".$user_email."' and binary Password='".$user_password."'";

			    $result = mysqli_query($conn,$sql_query);
			    $row = mysqli_fetch_array($result);

			    $count = $row['cntUser'];

			    if($count > 0){
			        header("Location: admin_account.php?email=".$user_email);
			    }else{
			    	echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			        echo "<dialog open>Invalid Email or Password or User Type</dialog>";
			    }

		    }

		}
		else{
			if ($user_email!= "" && $user_password != ""){

			$sql_query = "select count(*) as cntUser from member where Email='".$user_email."' and binary Password='".$user_password."'";
			$result = mysqli_query($conn,$sql_query);
			$row = mysqli_fetch_array($result);
			$count = $row['cntUser'];
		
			if($count > 0){   

				$sql1 = "select * from member where Email ='".$user_email."'";
				$result1 = $conn->query($sql1); 
			    if (mysqli_num_rows($result1) > 0) { 
			       
			        while ($row1 = mysqli_fetch_array($result1)) { 
			           $user_id = $row1["Memeber_id"];
			        } 
			        
			        unset($result1); 
			    } 

			    //checking whether that id is in the Student table
			    $sql_query2 = "select count(*) as cntStaff from staff where staff.`Staff-id` ='".$user_id."' ";
				$result2 = mysqli_query($conn,$sql_query2);
				$row2 = mysqli_fetch_array($result2);
				$count2 = $row2['cntStaff'];
				if ($count2 > 0 ){
					header("Location: usersf_account.php ?email=".$user_email);
				}
				else{
					echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>Invalid Email or Password or User Type</dialog>";
				}
    
			 }else{
			 	echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			    echo "<dialog open>Invalid Email or Password or User Type</dialog>";
			 }

	      }
		}
		
?>

