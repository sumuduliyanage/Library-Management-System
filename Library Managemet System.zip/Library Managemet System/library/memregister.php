<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;    
			    color: rgb(77,25,0);

			  }
			  input[type=submit] {
				  font-size: 16px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}
    	</style>
        <h1>Register A New User</h1>
    </head>
    <body>

    	<?php 
    		include 'db_connection.php';
			$conn = OpenCon();
			$adminemail = mysqli_real_escape_string($conn,$_POST["adminemail"]);
			echo "Admin<br>";
   			echo "You are logged as: ";
   			echo $adminemail;
   			echo "<br>";
		

        echo "<form action=\"memregisterscript.php\" method=\"post\">";
    	echo "<fieldset>";

    	  echo "<table width =\"500px\" class=\"center\">";
		   echo "<tr>";
			echo "<td>";
    		echo "<label for=\"fnamelbl\">First name :</label>";
    		echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"fname\"  name=\"fname\" required><br><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"lnamelbl\">Last name :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"lname\"  name=\"lname\" required><br><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"emaillbl\">Email :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"email\"  name=\"email\" required><br><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"adresslbl\">Adress</label><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"nolbl\">  No :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"no\"  name=\"no\" required><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"streetlbl\">Street :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"street\"  name=\"street\" required><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"citylbl\">City :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"city\"  name=\"city\" required><br><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"contactnolbl\">Contact No :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"contactno\" name=\"contactno\" required><br><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"passwordlbl\">Password :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<input type=\"text\" id=\"password\"  name=\"password\" required><br><br>";
			echo "</td>";
			echo "</tr>";

			echo "<tr>";
			echo "<td>";
			echo "<label for=\"usertypelbl\">User Type :</label>";
			echo "</td>";
    		echo "<td>";
			echo "<select id=\"type_user\" name=\"type_user\" autofocus>";
				echo "<option value=\"userst\">Student</option>";
				echo "<option value=\"usersf\">Staff</option>";  
			echo "</select><br><br>";
			echo "</td>";
			echo "</tr>";
	 			
	 		echo "<tr>";
			echo "<td>";	
			echo "<input type=\"hidden\" id=\"adminemail\"  name=\"adminemail\" value= \"$adminemail\" ><br><br>";		
			echo "</td>";
    		echo "<td>";  
			echo "<input type=\"submit\" id=\"register\"  maxlength=\"4\" size=\"50\" value=\"Register\">";
			echo "</td>";
			echo "</tr>";

			echo "</table>";

	    	echo "</fieldset>";
			  
			echo "</form>";

	?>

    </body>
</html>