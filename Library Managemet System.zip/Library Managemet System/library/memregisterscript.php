<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$fname = mysqli_real_escape_string($conn,$_POST["fname"]);
	$lname = mysqli_real_escape_string($conn,$_POST["lname"]);
	$email = mysqli_real_escape_string($conn,$_POST["email"]);
	$no = mysqli_real_escape_string($conn,$_POST["no"]);
	$street = mysqli_real_escape_string($conn,$_POST["street"]);
	$city = mysqli_real_escape_string($conn,$_POST["city"]);
	$contactno = mysqli_real_escape_string($conn,$_POST["contactno"]);
	$password = mysqli_real_escape_string($conn,$_POST["password"]);
	$type_user = mysqli_real_escape_string($conn,$_POST["type_user"]);
	$adminemail = mysqli_real_escape_string($conn,$_POST["adminemail"]);
	$memberid;
	$adminid;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	


	$sql_query = "select count(*) as cntUser from member where Email='".$email."' ";

	$result = mysqli_query($conn,$sql_query);
	$row = mysqli_fetch_array($result);

	$count = $row['cntUser'];
		
	if($count > 0){    
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "ERROR : Sorry!! That Email Is Already Registered. Use Another Email";
		echo "</dialog>";
			        
	}else{

		$sql_query1 = "select * from librarian where Email_address ='".$adminemail."' ";
		$res1 = $conn->query($sql_query1);
		if (mysqli_num_rows($res1) > 0) { 
						       
				while ($ro1 = mysqli_fetch_array($res1)) { 
					$adminid  = $ro1["Librarian_id"];
				} 
						        
				unset($res1); 
		} 



		$sql1 = "INSERT INTO `member` (`Memeber_id`, `Fine`, `Email`, `Password`, `Librarian_id`) VALUES (NULL, '0', '".$email."', '".$password."', '".$adminid."')";

		if(mysqli_query($conn, $sql1)){

			$sql2 = "select * from member where Email ='".$email."' ";
			$result2 = $conn->query($sql2); 
			if (mysqli_num_rows($result2) > 0) { 
						       
				while ($row2 = mysqli_fetch_array($result2)) { 
					$memberid  = $row2["Memeber_id"];
				} 
						        
				unset($result2); 
			} 

			if ($type_user == "userst"){
				$sql3 = "INSERT INTO `student` (`Student_id`, `No_address`, `Street_address`, `City_address`, `First_name`, `Last_name`, `Contact_no`) VALUES ('".$memberid."', '".$no."', '".$street."', '".$city."', '".$fname."', '".$lname."', '".$contactno."')";

				if (mysqli_query($conn,$sql3)){
					echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "<br>";
					echo "Member Was Registered Successfully.";
					echo "<br><br>";
					echo "Member Details";
					echo "<br><br>";
					echo "Member Id: ".$memberid."<br><br>";
					echo "Name: ".$fname." ".$lname."<br><br>";
					echo "Email: ".$email."<br><br>";
					echo "Address: ".$no.", ".$street.", ".$city."<br><br>";
					echo "Contact No: ".$contactno."<br><br>";
					echo "Type: "."Student"."<br><br>";
					echo "</dialog>"; 
				}

				else{
					echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
				}



			}

			elseif ($type_user == "usersf") {
				$sql4 = "INSERT INTO `staff` (`Staff-id`, `No_address`, `Street_address`, `City_address`, `First_name`, `Last_name`, `Contact_no`) VALUES ('".$memberid."', '".$no."', '".$street."', '".$city."', '".$fname."', '".$lname."', '".$contactno."')";


				if (mysqli_query($conn,$sql4)){
					echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "<br>";
					echo "Member Was Registered Successfully.";
					echo "<br><br>";
					echo "Member Details";
					echo "<br><br>";
					echo "Member Id: ".$memberid."<br><br>";
					echo "Name: ".$fname." ".$lname."<br><br>";
					echo "Email: ".$email."<br><br>";
					echo "Address: ".$no.", ".$street.", ".$city."<br><br>";
					echo "Contact No: ".$contactno."<br><br>";
					echo "Type: "."Staff"."<br><br>";
					echo "</dialog>"; 
				}

				else{
					echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
				}
			}

	
		} else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}

			     
	}



	
?>