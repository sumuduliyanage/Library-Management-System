<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$memid = mysqli_real_escape_string($conn,$_POST["memid"]);
	$email = mysqli_real_escape_string($conn,$_POST["email"]);
	$fname;
	$lname;
	$contactno;
	$no;
	$street;
	$city;
	$type; 
	$password;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	if ($memid != ""){


		$sql = "select count(*) as cntUser from member where Memeber_id ='".$memid."'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_array($result);
		$count = $row['cntUser'];
		if ($count <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Member Id <br> The Member Id You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{

			//geting the particular email address
			$sql1 = "select * from member where Memeber_id ='".$memid."' ";
			$result1 = $conn->query($sql1); 
			if (mysqli_num_rows($result1) > 0) { 			       
				while ($row1 = mysqli_fetch_array($result1)) { 
					$email = $row1["Email"];
					$password = $row1["Password"];
				} 				        
				unset($result1); 				
			}

			//checking whether the user is a student
			$sql2 = "select count(*) as cntSt from student where Student_id ='".$memid."' ";
			$result2 = mysqli_query($conn,$sql2);
			$row2 = mysqli_fetch_array($result2);
			$count2 = $row2['cntSt'];

			//if the user is a student
			if ($count2 > 0){

				$sql3 = "select * from student where Student_id ='".$memid."' ";
				$result3 = $conn->query($sql3); 
				if (mysqli_num_rows($result3) > 0) { 			       
					while ($row3 = mysqli_fetch_array($result3)) { 
						$fname = $row3["First_name"];
						$lname = $row3["Last_name"];
						$contactno = $row3["Contact_no"];
						$no = $row3["No_address"];
						$street = $row3["Street_address"];
						$city = $row3["City_address"];
						$type = "Student";
					} 				        
					unset($result3); 				
				}

			}
			//if the user is a staff member
			else{

				$sql3 = "select * from staff where staff.`Staff-id` ='".$memid."' ";
				$result3 = $conn->query($sql3); 
				if (mysqli_num_rows($result3) > 0) { 			       
					while ($row3 = mysqli_fetch_array($result3)) { 
						$fname = $row3["First_name"];
						$lname = $row3["Last_name"];
						$contactno = $row3["Contact_no"];
						$no = $row3["No_address"];
						$street = $row3["Street_address"];
						$city = $row3["City_address"];
						$type = "Staff";
					} 				        
					unset($result3); 				
				}
	

			}
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Results 1 <br><br> ";
			echo "__________________________________________________________________________<br><br>";
			echo "Member Id: ".$memid."<br><br>";
			echo "Name: ".$fname." ".$lname."<br><br>";
			echo "Email: ".$email."<br><br>";
			echo "Password: ".$password."<br><br>";
			echo "Type: ".$type."<br><br>";
			echo "Contact No: ".$contactno."<br><br>";
			echo "Address: ".$no." ,"."$street"." ,".$city."<br><br>";
			echo "</dialog>"; 
			echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";

		}
		


	}
	elseif ($email != "") {
		$sql = "select count(*) as cntUser from member where Email ='".$email."'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_array($result);
		$count = $row['cntUser'];
		if ($count <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Email <br> The Email You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{

			//geting the particular email address
			$sql1 = "select * from member where Email ='".$email."' ";
			$result1 = $conn->query($sql1); 
			if (mysqli_num_rows($result1) > 0) { 			       
				while ($row1 = mysqli_fetch_array($result1)) { 
					$memid = $row1["Memeber_id"];
					$password = $row1["Password"];
				} 				        
				unset($result1); 				
			}

			//checking whether the user is a student
			$sql2 = "select count(*) as cntSt from student where Student_id ='".$memid."' ";
			$result2 = mysqli_query($conn,$sql2);
			$row2 = mysqli_fetch_array($result2);
			$count2 = $row2['cntSt'];

			//if the user is a student
			if ($count2 > 0){

				$sql3 = "select * from student where Student_id ='".$memid."' ";
				$result3 = $conn->query($sql3); 
				if (mysqli_num_rows($result3) > 0) { 			       
					while ($row3 = mysqli_fetch_array($result3)) { 
						$fname = $row3["First_name"];
						$lname = $row3["Last_name"];
						$contactno = $row3["Contact_no"];
						$no = $row3["No_address"];
						$street = $row3["Street_address"];
						$city = $row3["City_address"];
						$type = "Student";
					} 				        
					unset($result3); 				
				}

			}
			//if the user is a staff member
			else{

				$sql4 = "select * from staff where staff.`Staff-id` ='".$memid."' ";
				$result4 = $conn->query($sql4); 
				if (mysqli_num_rows($result4) > 0) { 			       
					while ($row3 = mysqli_fetch_array($result4)) { 
						$fname = $row3["First_name"];
						$lname = $row3["Last_name"];
						$contactno = $row3["Contact_no"];
						$no = $row3["No_address"];
						$street = $row3["Street_address"];
						$city = $row3["City_address"];
						$type = "Staff";
					} 				        
					unset($result4); 				
				}

			}
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Results 1 <br><br> ";
			echo "__________________________________________________________________________<br><br>";
			echo "Member Id: ".$memid."<br><br>";
			echo "Name: ".$fname." ".$lname."<br><br>";
			echo "Email: ".$email."<br><br>";
			echo "Password: ".$password."<br><br>";
			echo "Type: ".$type."<br><br>";
			echo "Contact No: ".$contactno."<br><br>";
			echo "Address: ".$no." ,"."$street"." ,".$city."<br><br>";
			echo "</dialog>"; 
			echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";

		}
		
	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Empty Search!!!!!!!!!!! ";
		echo "</dialog>"; 
	}

?>