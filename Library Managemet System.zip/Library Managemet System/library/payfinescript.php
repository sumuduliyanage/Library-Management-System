<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$member_id = mysqli_real_escape_string($conn,$_POST["member_id"]);
	$fine_amount = mysqli_real_escape_string($conn,$_POST["fine_amount"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql_query2 = "select count(*) as noUser from member where Memeber_id ='".$member_id."'";
	$result4 = mysqli_query($conn,$sql_query2);
	$row4 = mysqli_fetch_array($result4);
	$countnouser = $row4['noUser'];

	//checking whether the user id is valid
	if ($countnouser<1){
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "ERROR <br>Wrong Member ID <br>There Is No Member With That ID";
		echo "</dialog>";
	}
	else{
		$fine;
		$email;
		$balance;

		$sql1 = "select * from member where Memeber_id ='".$member_id."'";
		$result1 = $conn->query($sql1); 

		if (mysqli_num_rows($result1) > 0) { 
						       
			while ($row1 = mysqli_fetch_array($result1)) { 
				$fine = $row1["Fine"];
				$email = $row1["Email"];
			} 			        
			unset($result1);				
		} 

		if ($fine == 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "ERROR <br>Sorry, There Is No Fine For The User.<br>Thank You!";
			echo "</dialog>";
		}
		else{
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Paymenet Was Successful";
			echo "<br><br> <br>Payment Summary<br><br><br>";
			echo "Member Id: ".$member_id."<br><br>";
			echo "Email: ".$email."<br><br>";
			echo "Fine To Pay(Rs): ".$fine."<br><br><br>";
			echo "Amount You paid(Rs): ".$fine_amount."<br><br>";
			$balance = $fine - $fine_amount;

			if($balance <= 0){
				$sql2 = "UPDATE `member` SET `Fine` = '0' WHERE `member`.`Memeber_id` = '".$member_id."'";
				if(mysqli_query($conn, $sql2)){
					echo "balance(Rs)(Please Return To User): ".($balance*-1)."<br><br>";
					echo "Current Fine To Pay(Rs) : 0";
					echo "<br><br>Thank You!";
				} else{
					echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
				}
			}
			else{
				$sql3 = "UPDATE `member` SET `Fine` = '".$balance."' WHERE `member`.`Memeber_id` = '".$member_id."'";
				if(mysqli_query($conn, $sql3)){
					echo "balance(Rs)(Please Take From user): ".$balance."<br><br>";
					echo "Current Fine To Pay(Rs) :".$balance."<br><br>";
					echo "<br>Thank You!";
				} else{
					echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
				}
			}

			echo "</dialog>";
	}
	

	}





	

?>