<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }
			  input[type=submit] {
				  font-size: 16px;
				  color: black;
				  height: 31px;
				  background: white;
				  align-self: center;	  
			}
    	</style>
        <h1>Register A Publisher</h1>
    </head>
    <body>
        <form action="pubregscript.php" method="post">
    		<fieldset>
    		<table width ="500px" class="center">

    		  <tr>
    		  	<td>
    		  <label for="namelbl">Name :</label>
    		</td>
    		<td>
			  <input type="text" id="name"  name="name" required><br><br>
			 </td>
			</tr>


			  <tr>
    		  	<td>
			  <label for="contactnolbl">Contact No :</label>
			  </td>
    		<td>
			  <input type="text" id="contactno" name="contactno" required><br><br>
			  </td>
			</tr>

				<tr>
    		  	<td>
			  <label for="addresslbl">Address :</label>
			   </td>
    		<td>
			  <input type="text" id="adress"  name="address" size="40" required><br><br>
			  </td>
			</tr>

  			<tr>
    		  	<td>
    		   </td>
    		<td>
			  <input type="submit" id="required"  maxlength="4" size="50" value="Register">
			 </td>
			</tr>
		</table>

    		</fieldset>
		  
		</form>
    </body>
</html>