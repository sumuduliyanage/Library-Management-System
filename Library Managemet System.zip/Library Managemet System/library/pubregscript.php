<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$name = mysqli_real_escape_string($conn,$_POST["name"]);
	$contactno = mysqli_real_escape_string($conn,$_POST["contactno"]);
	$address = mysqli_real_escape_string($conn,$_POST["address"]);
	$pubid;
	echo "<body style='background-color:rgb(204, 204, 255)'>";
	$sql1 = "INSERT INTO `publisher` (`Pub_id`, `Pub_name`, `Contact_no`, `Address`) VALUES (NULL, '".$name."', '".$contactno."', '".$address."')";
	
	if(mysqli_query($conn, $sql1)){

		$sql2 = "SELECT * FROM publisher WHERE Pub_id = (SELECT max(Pub_id) FROM publisher)";

		$result2 = $conn->query($sql2); 
		if (mysqli_num_rows($result2) > 0) { 
						       
			while ($row2 = mysqli_fetch_array($result2)) { 
				$pubid = $row2["Pub_id"];
			} 
						        
				unset($result2); 
						
		} 

		echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "publisher Was Registered Successfully.";
		echo "<br><br>Details: <br><br><br>";
		echo "publisher Id: ".$pubid."<br><br>";
		echo "Name: ".$name."<br><br>";
		echo "Contact No: ".$contactno."<br><br>";
		echo "Address: ".$address."<br><br>";
		echo "<br>Thank You!";
		echo "</dialog>"; 
	} else{
		echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
	}
	

?>