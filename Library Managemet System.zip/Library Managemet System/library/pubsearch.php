<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$pubid = mysqli_real_escape_string($conn,$_POST["pubid"]);
	$name = mysqli_real_escape_string($conn,$_POST["name"]);

	$contactno;
	$address;
	$j = 1;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	if ($pubid != ""){

		//checking Whether Given pubid Is In The table
		$sql = "select count(*) as cntPub from publisher where Pub_id ='".$pubid."'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_array($result);
		$count = $row['cntPub'];
		if ($count <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Publisher Id <br> The Publisher Id You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{

			$sql1 = "select * from publisher where Pub_id ='".$pubid."' ";
			$result1 = $conn->query($sql1); 
			if (mysqli_num_rows($result1) > 0) { 			       
				while ($row1 = mysqli_fetch_array($result1)) { 
					$name = $row1["Pub_name"];
					$contactno = $row1["Contact_no"];
					$address = $row1["Address"];
				} 				        
				unset($result1); 				
			}
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Results 1 <br><br><br> ";
			echo "__________________________________________________________________________<br><br>";
			echo "Publisher Id: ".$pubid."<br><br>";
			echo "Name: ".$name."<br><br>";
			echo "Contact No: ".$contactno."<br><br>";
			echo "Address: ".$address."<br><br>";
			echo "</dialog>"; 
		}

	}
	elseif ($name != "") {
		//checking Whether Given pubid Is In The table
		$sql = "select count(*) as cntPub from publisher where Pub_name ='".$name."'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_array($result);
		$count = $row['cntPub'];
		if ($count <= 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!Wrong Publisher Name <br> The Publisher Name You Searched Is Not Available.! ";
			echo "</dialog>"; 
		}
		else{

			$sql1 = "select * from publisher where Pub_name ='".$name."' ";
			$result1 = $conn->query($sql1); 
			if (mysqli_num_rows($result1) > 0) { 			       
				while ($row1 = mysqli_fetch_array($result1)) { 
					$pubid = $row1["Pub_id"];
					$contactno = $row1["Contact_no"];
					$address = $row1["Address"];

					echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"300\" height=\"300\" class=\"center\"><br>";
					echo "<dialog open>";
					echo "Results ".$j."<br><br><br> ";
					echo "__________________________________________________________________________<br><br>";
					echo "Publisher Id: ".$pubid."<br><br>";
					echo "Name: ".$name."<br><br>";
					echo "Contact No: ".$contactno."<br><br>";
					echo "Address: ".$address."<br><br>";
					echo "</dialog>"; 
					echo "<br><br><br><br><br><br><br><br><br><br><br>";

					$j = $j + 1;

				} 				        
				unset($result1); 				
			}

		}
		
	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Empty Search!!!!!!!!!!! ";
		echo "</dialog>"; 
	}

?>