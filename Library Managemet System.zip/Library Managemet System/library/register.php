<!DOCTYPE html>
<html>
    <head>

    	 <style>
			body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  input[type=submit] {
				  font-size: 25px;
				  color: rgb(13, 13, 112);  
				  height: 50px;
				  width: 500px;
				  background: rgb(114, 114, 130);
				  align-self: center;
				  border-radius: 12px;	  
			}

			  
		</style>

		<h1>New Registrations</h1>
        
    </head>
    <body>
    	<img src="photos/picregister.png" alt="Register" width="100" height="100" class="center"><br><br>
    	<label for="admin">Admin</label><br>
    	<label for="emaillabeladmin">You are logged as :</label>

        <?php
        	include 'db_connection.php';
        	$conn = OpenCon();
        	$email = mysqli_real_escape_string($conn,$_POST["adminemail"]);;
        	echo $email;

        	echo "<br>";
			echo "<br>";

			echo "<form action=\"memregister.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
        	echo "<input type=\"submit\" id=\"button4\"  maxlength=\"4\" size=\"50\" value=\"New Member Registration\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"bookregister.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button5\"  maxlength=\"4\" size=\"50\" value=\"New Book Registration\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"authorregister.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button6\"  maxlength=\"4\" size=\"50\" value=\"New Author Registration\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"publisherregister.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button7\"  maxlength=\"4\" size=\"50\" value=\"New Publisher Registration\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

        	echo "</form>";	   	


        ?>
    </body>
</html>