<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;

			  }
			  h2{
			  	
			  	font-size: 25px;
			  	text-align: center;
			  	color: rgb(0,0,128);
			  }
			  h3{
			  	
			  	font-size: 25px;
			  	text-align: center;
			  	color: rgb(0,0,128);
			  }
			  h4{
			  	
			  	font-size: 25px;
			  	text-align: center;
			  	color: rgb(0,0,128);
			  }
			  h5{
			  	
			  	font-size: 25px;
			  	text-align: center;
			  	color: rgb(0,0,128);
			  }

			  img{
			  	 display: block;
			  margin-left: auto;
			  margin-right: auto;
			  }


    	</style>
        <h1>Search An Item</h1>
    </head>
    <body>
    	<img src="photos/picsearch.png" alt="Search" width="100" height="100" class="center"><br><br>
    	<h2>Search A Book</h2><br>
        <form action="booksearch.php" method="post">
    		<fieldset>
    		  <label for="serchbidlbl">Search By Book Id</label><br>
    		  <label for="bookidlbl">Book Id: </label>
			  <input type="text" id="bookid"  name="bookid" required>
			  <input type="hidden" name="title" value=""/>
			  <input type="submit" id="search1"  maxlength="4" size="50" value="Search"><br><br>
	 
    		</fieldset>  
		</form>

		<form action="booksearch.php" method="post">
			<fieldset>
			  <label for="serchbnamelbl">Search By Book Title</label><br>
    		  <label for="booknamelbl">Book Title: </label>
    		  <input type="hidden" name="bookid" value=""/>
			  <input type="text" id="title"  name="title" required>
			  <input type="submit" id="search2"  maxlength="4" size="50" value="Search"><br>
			</fieldset>
		</form>

		<br><br><br>
		<h3>Search A Member</h3><br>
		<form action="memsearch.php" method="post">
    		<fieldset>
    		  <label for="serchbidlbl">Search By Member Id</label><br>
    		  <label for="memidlbl">Member Id: </label>
			  <input type="text" id="memid"  name="memid" required>
			  <input type="hidden" name="email" value=""/>
			  <input type="submit" id="search1"  maxlength="4" size="50" value="Search"><br><br>
    		</fieldset>  
		</form>

		<form action="memsearch.php" method="post">
			<fieldset>
			  <label for="serchbemaillbl">Search By Email </label><br>
    		  <label for="mememaillbl">Email Address: </label>
			  <input type="text" id="email"  name="email" required>
			  <input type="hidden" name="memid" value=""/>
			  <input type="submit" id="search2"  maxlength="4" size="50" value="Search"><br> 
			</fieldset>
		</form>



		<br><br><br>
		<h4>Search An Author</h4><br>
		<form action="authorsearch.php" method="post">
    		<fieldset>
    		  <label for="serchbidlbl">Search By Author Id</label><br>
    		  <label for="auidlbl">Author Id: </label>
			  <input type="text" id="authorid"  name="authorid" required>
			  <input type="hidden" name="fname" value=""/>
			  <input type="hidden" name="lname" value=""/>
			  <input type="submit" id="search1"  maxlength="4" size="50" value="Search"><br><br>  
    		</fieldset>  
		</form>

		<form action="authorsearch.php" method="post">
			<fieldset>
			  <label for="serchnamelbl">Search By Author Name</label><br>
    		  <label for="authorfnmaelbl">First Name: </label>
			  <input type="text" id="fname"  name="fname" required>
			  <label for="authorlnmaelbl">Last Name: </label>
			  <input type="text" id="lname"  name="lname">
			  <input type="hidden" name="authorid" value=""/>
			  <input type="submit" id="search2"  maxlength="4" size="50" value="Search"><br>  
			</fieldset>
		</form>


		<br><br><br>
		<h5>Search A Publisher</h5><br>
		<form action="pubsearch.php" method="post">
    		<fieldset>
    		  <label for="serchbidlbl">Search By Publisher Id</label><br>
    		  <label for="pubidlbl">Publisher Id: </label>
			  <input type="text" id="pubid"  name="pubid" required>
			  <input type="hidden" name="name" value=""/>
			  <input type="submit" id="search1"  maxlength="4" size="50" value="Search"><br><br>  
    		</fieldset>  
		</form>

		<form action="pubsearch.php" method="post">
			<fieldset>
			  <label for="serchbnamelbl">Search By Name</label><br>
    		  <label for="pubnamebl">Publisher Name: </label>
			  <input type="text" id="name"  name="name" required>
			  <input type="hidden" name="pubid" value=""/>
			  <input type="submit" id="search2"  maxlength="4" size="50" value="Search"><br>
			</fieldset>
		</form>



    </body>
</html>