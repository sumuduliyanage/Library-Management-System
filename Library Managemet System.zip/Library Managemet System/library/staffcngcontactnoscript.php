<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$contactno = mysqli_real_escape_string($conn,$_POST["contactno"]);
	$email = mysqli_real_escape_string($conn,$_POST["adminemail"]);
	$memid = mysqli_real_escape_string($conn,$_POST["mem_id"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";
	

	$numlength = strlen((string)$contactno);
	$no = (string)$contactno;

	if (($numlength == 10) && ($no[0] == "0")){
		

		$sql_query1 = "UPDATE `staff` SET `Contact_no` = '".$contactno."' WHERE `staff`.`Staff-id` = '".$memid."'";

		if(mysqli_query($conn, $sql_query1)){
			echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"250\" height=\"250\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Contact No  Was Changed Successfully";
			echo "</dialog>";
					
				
		} else{
			echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
		}
	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"250\" height=\"250\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Incorrect Contact No Format.<br>Expected Type = 07xxxxxxxx";
		echo "</dialog>";
	}

	

?>