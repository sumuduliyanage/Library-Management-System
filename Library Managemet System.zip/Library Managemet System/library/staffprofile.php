<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$memid = mysqli_real_escape_string($conn,$_POST["mem_id"]);
	$email = mysqli_real_escape_string($conn,$_POST["email"]);
	$password;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	$sql5 = "select * from member where Memeber_id ='".$memid."'";
	$result5 = $conn->query($sql5); 
	if (mysqli_num_rows($result5) > 0) { 		       
		while ($row5 = mysqli_fetch_array($result5)) { 
			$password = $row5["Password"]; 
		}     
		unset($result5); 
	} 


	$sql2 = "SELECT * FROM staff WHERE staff.`Staff-id` = '".$memid."' ";

	$result2 = $conn->query($sql2); 
	if (mysqli_num_rows($result2) > 0) { 
					       
		while ($row2 = mysqli_fetch_array($result2)) { 
						
			echo "<dialog open>";
			echo "Member Id: ".$memid."<br><br>";
			echo "Email: ".$email."<br><br>";
			echo "Name: ".$row2["First_name"]." ".$row2["Last_name"]."<br><br>";
			echo "Address :"."<br>";
			echo "No: ".$row2["No_address"]."<br>";
			echo "Street: ".$row2["Street_address"]."<br>";
			echo "City: ".$row2["City_address"]."<br><br>";
			echo "Contact No: ".$row2["Contact_no"]."<br>";
			echo "</dialog>"; 
			
		} 		        
		unset($result2); 
							
	} 


?>