<!DOCTYPE html>
<html>
    <head>
        <style>
			body {background-color:rgb(204, 204, 255);}

			label{
				font-size: 32px;
				text-align: left;
				margin:auto;
			}

			.button {
			  border: none;
			  color: white;
			  padding: 16px 80px;
			  text-align: center;
			  text-decoration: none;
			  display: inline-block;
			  font-size: 16px;
			  margin: 4px 2px;
			  transition-duration: 0.4s;
			  cursor: pointer;
			  margin:auto;
			}


			  .wrapper {
			   text-align: center;}

			   label[for= "heading"]{
				text-align: center;
				font-size: 250%;
				margin:auto;

				}

				input[type=submit] {
				  font-size: 25px;
				  color: rgb(13, 13, 112);  
				  height: 50px;
				  width: 500px;
				  background: rgb(114, 114, 130);
				  align-self: center;
				  border-radius: 12px;	  
			}

				.wrapper2 {
			   text-align: center;}

			   .wrapper3 {
			   text-align: center;}

			   .wrapper4 {
			   text-align: center;}

			   h1{
			  	
			  	font-size: 35px;
			  	text-align: center;
			  }

			  img {
			  margin: auto;
			  display: block;
			}

		</style>

		<h1>Settings</h1>

    </head>
    <body>
        <?php
        	include 'db_connection.php';
        	$conn = OpenCon();
			$mem_id = mysqli_real_escape_string($conn,$_POST["mem_id"]);
			$email = mysqli_real_escape_string($conn,$_POST["email"]);

		
			echo "<img src=\"photos/picsettings.jpg\" alt=\"Settings\" width=\"100\" height=\"100\" class=\"center\"><br><br>";

		    echo "<br>";
		    echo "<div class=\"wrapper\">";

		    echo "<form action=\"studentemailcng.php\" method=\"post\">";
		    echo "<input type=\"hidden\" name=\"mem_id\" value=\"$mem_id\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\"/> ";
        	echo "<input type=\"submit\" id=\"button1\"  maxlength=\"4\" size=\"50\" value=\"Change Email\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"studentpasswordcng.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"mem_id\" value=\"$mem_id\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\"/> ";//sending the logging libarary admin email
        	echo "<input type=\"submit\" id=\"button2\"  maxlength=\"4\" size=\"50\" value=\"Change Password\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"staffcontactnocng.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"mem_id\" value=\"$mem_id\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\"/> ";
        	echo "<input type=\"submit\" id=\"button3\"  maxlength=\"4\" size=\"50\" value=\"Change Contact No\">";
        	echo "</form>";

        	echo "</div>";

        	echo "<br>";
		   

		    
   

		?>
    </body>
</html>
