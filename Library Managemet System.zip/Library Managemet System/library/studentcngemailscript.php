<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$newemail = mysqli_real_escape_string($conn,$_POST["newemail"]);
	$oldemail = mysqli_real_escape_string($conn,$_POST["oldemail"]);
	//$trueemail = mysqli_real_escape_string($conn,$_POST["adminemail"]);
	$memid = mysqli_real_escape_string($conn,$_POST["mem_id"]);

	echo "<body style='background-color:rgb(204, 204, 255)'>";


	$sql = "select * from member where Memeber_id ='".$memid."'";
	$result = $conn->query($sql); 
	if (mysqli_num_rows($result) > 0) { 	       
		while ($row = mysqli_fetch_array($result)) { 
			$trueemail = $row["Email"];
		} 
			        
		unset($result); 
	} 


	if ($oldemail == $trueemail){
		$sql1 = "select count(*) as cntEmail from member where Email ='".$newemail."'";
		$result1 = mysqli_query($conn,$sql1);
		$row1 = mysqli_fetch_array($result1);
		$countemail = $row1['cntEmail'];
		if ($countemail > 0){
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!New Email Is Already Used! ";
			echo "</dialog>"; 
		}
		else{
			
			$sql_query1 = "UPDATE `member` SET `Email` = '".$newemail."' WHERE `member`.`Memeber_id` = '".$memid."'";

			if(mysqli_query($conn, $sql_query1)){
				echo "<img src=\"photos/pichappy.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
				echo "<dialog open>";
				echo "Email Was Changed Successfully";
				echo "</dialog>";
				
			
			} else{
				echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
			}

		}

	}
	else{
		echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
		echo "<dialog open>";
		echo "Error!!<br>Current Email Is Wrong";
		echo "</dialog>"; 
	}


?>