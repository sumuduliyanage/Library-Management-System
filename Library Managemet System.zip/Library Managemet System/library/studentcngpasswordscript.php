<?php
	include 'db_connection.php';

	
	$conn = OpenCon();

	$newpassword = mysqli_real_escape_string($conn,$_POST["newpassword"]);
	$oldpassword = mysqli_real_escape_string($conn,$_POST["oldpassword"]);
	$trueemail = mysqli_real_escape_string($conn,$_POST["adminemail"]);
	$memid = mysqli_real_escape_string($conn,$_POST["mem_id"]);
	$truepassword;

	echo "<body style='background-color:rgb(204, 204, 255)'>";

	//getting the true password according to the email
	$sql4 = "SELECT * FROM member WHERE Memeber_id = '".$memid."' ";
	$result4 = $conn->query($sql4); 
	if (mysqli_num_rows($result4) > 0) { 				       
		while ($row4 = mysqli_fetch_array($result4)) { 
			$truepassword = $row4["Password"];
		} 
							        
		unset($result4); 						

		if ($oldpassword == $truepassword){


			$sql_query1 = "UPDATE `member` SET `Password` = '".$newpassword."' WHERE `member`.`Memeber_id` = '".$memid."'";

			if(mysqli_query($conn, $sql_query1)){
				echo "<img src=\"photos/pichappy.jpg\" alt=\"Happy\" width=\"250\" height=\"250\" class=\"center\"><br>";
				echo "<dialog open>";
				echo "Password Was Changed Successfully";
				echo "</dialog>";
					
				
			} else{
					echo "ERROR:Sorry, Could not able to execute your Request." . mysqli_error($conn);
			}

		}
		else{
			echo "<img src=\"photos/picsad.jpg\" alt=\"Sad\" width=\"300\" height=\"300\" class=\"center\"><br>";
			echo "<dialog open>";
			echo "Error!!<br>Current Password Is Wrong";
			echo "</dialog>"; 
		}
	}

?>