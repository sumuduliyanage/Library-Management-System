<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;    
			    

			  }
    	</style>
        <h1>Change Email Address</h1>
    </head>
    <body>

    	<?php 
    		include 'db_connection.php';
			$conn = OpenCon();
			$email = mysqli_real_escape_string($conn,$_POST["email"]);
			$memid = mysqli_real_escape_string($conn,$_POST["mem_id"]);

			
   			echo "<br>";
		

        	echo "<form action=\"studentcngemailscript.php\" method=\"post\">";
    		echo "<fieldset>";

    		echo "<label for=\"fnamelbl\">Current Email :</label>";
    		echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
			echo "<input type=\"text\" id=\"oldemail\"  name=\"oldemail\" required><br><br>";

			echo "<label for=\"lnamelbl\">New Email :</label>";
			echo "<input type=\"hidden\" name=\"mem_id\" value=\"$memid\"/> ";//sending the logging libarary admin email
			echo "<input type=\"text\" id=\"newemail\"  name=\"newemail\" required><br><br>";
	  
				  
			echo "<input type=\"submit\" id=\"change\"  maxlength=\"4\" size=\"50\" value=\"Change\">";

	    	echo "</fieldset>";
			  
			echo "</form>";

	?>

    </body>
</html>