<!DOCTYPE html>
<html>
    <head>
    	<style>
    		body {background-color:rgb(204, 204, 255);}

			
			  h1{
			  	font-size: 35px;
			  	text-align: center;
			  }

			  fieldset 
			  {
			    font-size:16px;
			    padding:20px;
			    width:640px;
			    line-height:1.3;
			    margin:  0px auto;    
			    

			  }
    	</style>
        <h1>Change Password</h1>
    </head>
    <body>

    	<?php 
    		include 'db_connection.php';
			$conn = OpenCon();
			$email = mysqli_real_escape_string($conn,$_POST["email"]);
			$memid = mysqli_real_escape_string($conn,$_POST["mem_id"]);

			
   			echo "<br>";
		

        	echo "<form action=\"studentcngpasswordscript.php\" method=\"post\">";
    		echo "<fieldset>";

    		echo "<label for=\"fnamelbl\">Current Password :</label>";
    		echo "<input type=\"hidden\" name=\"adminemail\" value=\"$email\"/> ";//sending the logging libarary admin email
			echo "<input type=\"password\" id=\"oldpassword\"  name=\"oldpassword\" required><br><br>";

			echo "<label for=\"lnamelbl\">New Password :</label>";
			echo "<input type=\"hidden\" name=\"mem_id\" value=\"$memid\"/> ";//sending the logging libarary admin email
			echo "<input type=\"password\" id=\"newpassword\"  name=\"newpassword\" required><br><br>";
	  
				  
			echo "<input type=\"submit\" id=\"change\"  maxlength=\"4\" size=\"50\" value=\"Change\">";

	    	echo "</fieldset>";
			  
			echo "</form>";

	?>

    </body>
</html>