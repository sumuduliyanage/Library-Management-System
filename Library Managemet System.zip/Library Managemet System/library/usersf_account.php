<!DOCTYPE html>
<html>
    <head>
        <style>
			body {background-color:rgb(204, 204, 255);}

			label{
				font-size: 32px;
				text-align: left;
				margin:auto;
			}

			.button {
			  border: none;
			  color: white;
			  padding: 16px 80px;
			  text-align: center;
			  text-decoration: none;
			  display: inline-block;
			  font-size: 16px;
			  margin: 4px 2px;
			  transition-duration: 0.4s;
			  cursor: pointer;
			  margin:auto;
			}


			  .wrapper {
			   text-align: center;}

			   label[for= "heading"]{
				text-align: center;
				font-size: 250%;
				margin:auto;

				}

				input[type=submit] {
				  font-size: 25px;
				  color: rgb(13, 13, 112);  
				  height: 50px;
				  width: 500px;
				  background: rgb(114, 114, 130);
				  align-self: center;
				  border-radius: 12px;	  
			}

				.wrapper2 {
			   text-align: center;}

			   .wrapper3 {
			   text-align: center;}

			   .wrapper4 {
			   text-align: center;}

		</style>

    </head>
    <body>
    	<p style="font-size:50px" align="center"><b>Welcome To The Library</b></p>
        <?php
        	include 'db_connection.php';
        	$conn = OpenCon();
			$email = $_GET['email'];
			$mem_id;
			$istransaction = 0;


			$sql1 = "select * from member where Email ='".$email."'";
			$result1 = $conn->query($sql1); 
		    if (mysqli_num_rows($result1) > 0) { 
		       
		        while ($row = mysqli_fetch_array($result1)) { 
		            
		            $mem_id = $row["Memeber_id"]; 
		            
		        } 
		        
		        unset($result1); 
		    } 

		    $book_id ;
		    $issue_id ;
		    $duration;
		    $issue_date;
		    $due_date;
		    $title;
		    $author_id;
		    $isbn;
		    $author_fname;
		    $author_lname;
		    $emptystr =" ";

		    $sql2 = "select * from borrow where Lib_card_no ='".$mem_id."' and Returned_date is null";
			$result2 = $conn->query($sql2); 
		    if (mysqli_num_rows($result2) > 0) { 
		       
		       $istransaction = 1;
		        while ($row = mysqli_fetch_array($result2)) { 
		            
		            $book_id = $row["Book_id"];
		            $issue_id = $row["Issue_id"]; 
		            $issue_date = $row["Issue_date"];
		            $duration = $row["Duration"];
		            $due_date = $row["Due_date"];
		        } 
		        
		        unset($result2); 


		        $sql3 = "select * from book where Book_id ='".$book_id."'";
				$result3 = $conn->query($sql3); 
			    if (mysqli_num_rows($result3) > 0) { 
			       
			        while ($row = mysqli_fetch_array($result3)) { 
			           $title = $row["Title"];
			           $author_id = $row["Author_id"];
			           $isbn = $row["Isbn_no"];
			        } 
			        
			        unset($result3); 
			    } 


			    $sql4 = "select * from author where Author_id ='".$author_id."'";
				$result4 = $conn->query($sql4); 
			    if (mysqli_num_rows($result4) > 0) { 
			       
			        while ($row = mysqli_fetch_array($result4)) { 
			           $author_fname = $row["Author_first_name"];
			           $author_lname = $row["Author_last_name"];
			        } 
			        
			        unset($result4); 
			    } 


		    } 


		    echo "<br>";
		    echo "<div class=\"wrapper\">";

		    echo "<form action=\"booksearchuser.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button1\"  maxlength=\"4\" size=\"50\" value=\"Search A Book\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"staffprofile.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"mem_id\" value=\"$mem_id\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\"/> ";//sending the logging libarary admin email
        	echo "<input type=\"submit\" id=\"button2\"  maxlength=\"4\" size=\"50\" value=\"Profile\">";
        	echo "</form>";

        	echo "<br>";
			//echo "<br>";

			echo "<form action=\"staffsettings.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"mem_id\" value=\"$mem_id\"/> ";//sending the logging libarary admin email
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\"/> ";
        	echo "<input type=\"submit\" id=\"button3\"  maxlength=\"4\" size=\"50\" value=\"Settings\">";
        	echo "</form>";

        	echo "<br>";

        	echo "<form action=\"index.php\" method=\"post\">";
        	echo "<input type=\"submit\" id=\"button4\"  maxlength=\"4\" size=\"50\" value=\"Log Out\">";
        	echo "</form>";

        	echo "</div>";

        	echo "<br>";




		    echo "<div class=\"wrapper2\">";
		    echo "<label for=\"heading\"><b>Your Details About The Current Transaction</b></label>";
		    echo "</div>";

		    if ($istransaction == 1){
		    echo "<br>";
		    echo "<br>";
		    echo "<div class=\"wrapper3\">";
		    echo "<label for=\"boodid\">Book ID   : </label>";
		    echo "<font color: black  size = \"6px\"> $book_id  </font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"issue_id\">Issue ID  : </label>";
		    echo "<font color: black  size = \"6px\">$issue_id</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"title\">Book Title  : </label>";
		    echo "<font color: black  size = \"6px\">$title</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"isbn\">ISBN NO  : </label>";
		    echo "<font color: black  size = \"6px\">$isbn</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"author\">Author : </label>";
		    echo  "<font color: black  size = \"6px\">$author_fname $emptystr $author_lname</font>" ;
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"issue_date\">Issued Date  : </label>";
		    echo "<font color: black  size = \"6px\">$issue_date</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"due_date\">Due Date  : </label>";
		    echo "<font color: black  size = \"6px\">$due_date</font>";
		    echo "<br>";
		    echo "<br>";

		   echo "<p style=\"color:rgb(10, 16, 87);\"><b>Your Fine Is 5Rs For A Late Day!<b></p>";
		    echo "</div>";

		    
		    }
		    else{
		    echo "<br>";

		    echo "<br>";
		    echo "<div class=\"wrapper4\">";
		    echo "<font color:rgb(0,85,128)  size = \"6px\">Currenly You Are Not Keeping Any Book</font>";
		    echo "<br>";
		    echo "<br>";
		    echo "<label for=\"boodid\">Book ID   : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"issue_id\">Issue ID  : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"title\">Book Title  : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"isbn\">ISBN NO  : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"author\">Author  : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"issue_date\">Issued Date  : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";

		    echo "<label for=\"due_date\">Due Date  : </label>";
		    echo "<font color: black  size = \"6px\">Not Available</font>";
		    echo "<br>";
		    echo "<br>";
		    echo "<br>";
		    echo "</div>";

		    }

		   



		?>
    </body>
</html>
