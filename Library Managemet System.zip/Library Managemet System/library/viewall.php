<!DOCTYPE html>
<html>
    <head>
        <style>
            body {background-color:rgb(204, 204, 255);   
            }
            h1 {
              color: rgb(0,0,0);
              text-align: center;
              font-family: verdana;
              font-size: 300%;
            }   
            label{
                color: black;
                font-size: 150%;
            }
            fieldset 
              {
                font-size:16px;
                padding:20px;
                width:640px;
                line-height:1.3;
                margin:  0px auto;

              }

            input[type=submit] {
          font-size: 25px;
          color: rgb(13, 13, 112);  
          height: 50px;
          width: 500px;
          background: rgb(114, 114, 130);
          align-self: center;
          border-radius: 12px;    
      }

        </style>
        <h1> View All Details </h1> 
    </head>

    <body>
      <br>
      <form action="viewtransactions.php" method="post"> 
        <input type="submit" id="button3"  maxlength="4" size="50" value="View All Transactions">
      </form>
      <br>
      <form action="viewbooks.php" method="post">
        
        <input type="submit" id="button3"  maxlength="4" size="50" value="View All Books">
        
      </form>
      <br>
      <form action="viewmembers.php" method="post">
        
        <input type="submit" id="button3"  maxlength="4" size="50" value="View All Members">
        
      </form>
      <br>
      <form action="viewauthors.php" method="post">
        
        <input type="submit" id="button3"  maxlength="4" size="50" value="View All Authors">
        
      </form>

      <br>

      <form action="viewpublishers.php" method="post">
        
        <input type="submit" id="button3"  maxlength="4" size="50" value="View All Publishers">
        
      </form>


       
        
    </body>
</html>