<!DOCTYPE html>
<html>
    <head>
        <style>
            body {background-color:rgb(204, 204, 255);   
            }
            h1 {
              color: rgb(0,0,0);
              text-align: center;
              font-family: verdana;
              font-size: 300%;
            }   
            
              .center {
				  margin-left: auto;
				  margin-right: auto;
				}

        </style>
        <h1> All Authors </h1> 
    </head>

    <body>
	    <?php
		include 'db_connection.php';

		
		$conn = OpenCon();
		$Author_id ;
	    $Author_first_name ;
	    $Author_last_name;
		

		$sql = "select * from author";
	    $result = $conn->query($sql);
	    if (mysqli_num_rows($result) > 0) {  
	    	echo "<table width =\"800px\" class=\"center\">";
		    	echo "<tr>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Author Id</b></label>";
				echo "</td>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>First Name</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Last Name</b></label>";
				echo "</td>";
				
				echo "</tr>";	                  
	        while ($row = mysqli_fetch_array($result)) { 
	        	$Author_id = $row["Author_id"];
	        	$Author_first_name = $row["Author_first_name"];
	        	$Author_last_name = $row["Author_last_name"];
	        	

	        	echo "<tr>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Author_id</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Author_first_name</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Author_last_name</label>";
					echo "</td>";
							
				echo "</tr>";
	            
	        }  
	        echo "</table>";                   
	        unset($result); 
	    } 

		?>
      
       
        
    </body>
</html>





