<!DOCTYPE html>
<html>
    <head>
        <style>
            body {background-color:rgb(204, 204, 255);   
            }
            h1 {
              color: rgb(0,0,0);
              text-align: center;
              font-family: verdana;
              font-size: 300%;
            }   
            
              .center {
				  margin-left: auto;
				  margin-right: auto;
				}

        </style>
        <h1> All Books </h1> 
    </head>

    <body>
	    <?php
		include 'db_connection.php';

		
		$conn = OpenCon();
		$Book_id;
	    $Title;
	    $Isbn_no;
	    $Lending_status;
	    $Availability;
	    $Price;
	    $Type;
	    $Author_id;
	    $Pub_id;
		

		$sql = "select * from book";
	    $result = $conn->query($sql);
	    if (mysqli_num_rows($result) > 0) {  
	    	echo "<table width =\"1200px\" class=\"center\">";
		    	echo "<tr>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Book Id</b></label>";
				echo "</td>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Title</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Isbn no</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Lending status</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Availability</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Price</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Type</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Author id</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Publisher Id</b></label>";
				echo "</td>";	
				echo "</tr>";	                  
	        while ($row = mysqli_fetch_array($result)) { 
	        	$Book_id = $row["Book_id"];
	        	$Title = $row["Title"];
	        	$Isbn_no = $row["Isbn_no"];
	        	$Lending_status = $row["Lending_status"];
	        	$Availability = $row["Availability"];
	        	$Price = $row["Price"];
	        	$Type = $row["Type"];
	        	$Author_id = $row["Author_id"];
	        	$Pub_id = $row["Pub_id"];

	        	

	        	echo "<tr>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Book_id</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Title</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Isbn_no</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Lending_status</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Availability</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Price</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Type</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Author_id</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Pub_id</label>";
					echo "</td>";
					
				echo "</tr>";
	            
	        }  
	        echo "</table>";                   
	        unset($result); 
	    } 

		?>
      
       
        
    </body>
</html>





