<!DOCTYPE html>
<html>
    <head>
        <style>
            body {background-color:rgb(204, 204, 255);   
            }
            h1 {
              color: rgb(0,0,0);
              text-align: center;
              font-family: verdana;
              font-size: 300%;
            }   
            
              .center {
				  margin-left: auto;
				  margin-right: auto;
				}

        </style>
        <h1> All Members </h1> 
    </head>

    <body>
	    <?php
		include 'db_connection.php';

		
		$conn = OpenCon();
		$First_name ;
		$Last_name;
		$Contact_no;
		$No_address;
		$Street_address;
		$City_address;
	    $Type;
		

		$sql = "select * from member";
	    $result = $conn->query($sql);
	    if (mysqli_num_rows($result) > 0) {  
	    	echo "<table width =\"1300px\" class=\"center\">";
		    	echo "<tr>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Member Id</b></label>";
				echo "</td>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Email</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Password</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>First Name</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Last Name</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Contact No</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Address No</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Street</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>City</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Type</b></label>";
				echo "</td>";	
				echo "</tr>";

	        while ($row = mysqli_fetch_array($result)) {
	        	$Memeber_id = $row["Memeber_id"];
	        	$Email = $row["Email"];
	        	$Password = $row["Password"];

	        	$sql1 = "select count(*) as cntSt from student where Student_id ='".$Memeber_id."'";
				$result1 = mysqli_query($conn,$sql1);
				$row1 = mysqli_fetch_array($result1);
				$countemail = $row1['cntSt'];

				if ($countemail > 0){

					$sql2 = "select * from student where student.`Student_id` ='".$Memeber_id."' ";
				    $result2 = $conn->query($sql2);
				    if (mysqli_num_rows($result2) > 0) {                    
				        while ($row2 = mysqli_fetch_array($result2)) { 
				            $First_name  = $row2["First_name"];
				            $Last_name  = $row2["Last_name"];
				            $Contact_no  = $row2["Contact_no"];
				            $No_address  = $row2["No_address"];
				            $Street_address  = $row2["Street_address"];
				            $City_address  = $row2["City_address"];
				            $Type = "Student";

				        }                     
				        unset($result2); 
				    } 

					
				}
				else{
					$sql2 = "select * from staff where staff.`Staff-id` ='".$Memeber_id."' ";
				    $result2 = $conn->query($sql2);
				    if (mysqli_num_rows($result2) > 0) {                    
				        while ($row2 = mysqli_fetch_array($result2)) { 
				            $First_name  = $row2["First_name"];
				            $Last_name  = $row2["Last_name"];
				            $Contact_no  = $row2["Contact_no"];
				            $No_address  = $row2["No_address"];
				            $Street_address  = $row2["Street_address"];
				            $City_address  = $row2["City_address"];
				            $Type = "Staff";

				        }                     
				        unset($result2); 
				    } 

				}
	        	

	        	

	        	echo "<tr>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Memeber_id</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Email</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Password</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$First_name</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Last_name</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Contact_no</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$No_address</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Street_address</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$City_address</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Type</label>";
					echo "</td>";
					
				echo "</tr>";
	            
	        }  
	        echo "</table>";                   
	        unset($result); 
	    } 

		?>
      
       
        
    </body>
</html>


