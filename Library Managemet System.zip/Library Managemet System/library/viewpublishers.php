<!DOCTYPE html>
<html>
    <head>
        <style>
            body {background-color:rgb(204, 204, 255);   
            }
            h1 {
              color: rgb(0,0,0);
              text-align: center;
              font-family: verdana;
              font-size: 300%;
            }   
            
              .center {
				  margin-left: auto;
				  margin-right: auto;
				}

        </style>
        <h1> All Publishers </h1> 
    </head>

    <body>
	    <?php
		include 'db_connection.php';

		
		$conn = OpenCon();
		$Pub_id ;
	    $Pub_name ;
	    $Contact_no ;
	    $Address;
		

		$sql = "select * from publisher";
	    $result = $conn->query($sql);
	    if (mysqli_num_rows($result) > 0) {  
	    	echo "<table width =\"800px\" class=\"center\">";
		    	echo "<tr>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Publisher Id</b></label>";
				echo "</td>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Name</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Cotact No</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Address</b></label>";
				echo "</td>";
				
				echo "</tr>";	                  
	        while ($row = mysqli_fetch_array($result)) { 
	        	$Pub_id = $row["Pub_id"];
	        	$Pub_name = $row["Pub_name"];
	        	$Contact_no = $row["Contact_no"];
	        	$Address = $row["Address"];
	        	

	        	echo "<tr>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Pub_id</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Pub_name</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Contact_no</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$Address</label>";
					echo "</td>";
							
				echo "</tr>";
	            
	        }  
	        echo "</table>";                   
	        unset($result); 
	    } 

		?>
      
       
        
    </body>
</html>





