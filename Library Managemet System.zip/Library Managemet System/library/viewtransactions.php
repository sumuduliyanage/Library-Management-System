<!DOCTYPE html>
<html>
    <head>
        <style>
            body {background-color:rgb(204, 204, 255);   
            }
            h1 {
              color: rgb(0,0,0);
              text-align: center;
              font-family: verdana;
              font-size: 300%;
            }   
            
              .center {
				  margin-left: auto;
				  margin-right: auto;
				}

        </style>
        <h1> All Transactions </h1> 
    </head>

    <body>
	    <?php
		include 'db_connection.php';

		
		$conn = OpenCon();
		$issue_id;
		$memberid;
		$bookid;
		$issuedate;
		$duration;
		$returned_date;
		$due_date;

		$sql = "select * from borrow";
	    $result = $conn->query($sql);
	    if (mysqli_num_rows($result) > 0) {  
	    	echo "<table width =\"850px\" class=\"center\">";
		    	echo "<tr>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Issued Id</b></label>";
				echo "</td>";
				echo "<td>";
					echo "<label for=\"emaillabel1\"><b>Member Id</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Book Id</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Issued Date</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Duration</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Returned Date</b></label>";
				echo "</td>";
				echo "<td>";
					  echo "<label for=\"emaillabel1\"><b>Due Date</b></label>";
				echo "</td>";	
				echo "</tr>";	                  
	        while ($row = mysqli_fetch_array($result)) { 
	        	$issue_id = $row["Issue_id"];
	        	$memberid = $row["Lib_card_no"];
	        	$bookid = $row["Book_id"];
	        	$issuedate = $row["Issue_date"];
	        	$duration = $row["Duration"];
	        	$returned_date = $row["Returned_date"];
	        	$due_date = $row["Due_date"];

	        	if ($returned_date == ""){
	        		$returned_date = "Not Returned";
	        	}

	        	echo "<tr>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$issue_id</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$memberid</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$bookid</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$issuedate</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$duration</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$returned_date</label>";
					echo "</td>";
					echo "<td>";
					  echo "<label for=\"emaillabel1\">$due_date</label>";
					echo "</td>";
					
				echo "</tr>";
	            
	        }  
	        echo "</table>";                   
	        unset($result); 
	    } 

		?>
      
       
        
    </body>
</html>





